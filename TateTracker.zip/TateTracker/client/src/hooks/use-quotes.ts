import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Quote } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

export function useRandomQuote() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [refreshKey, setRefreshKey] = useState(0);

  const { 
    data: quote,
    isLoading,
    isError 
  } = useQuery<Quote>({
    queryKey: ['/api/quotes/random', refreshKey],
    staleTime: Infinity, // Don't refetch automatically
  });

  const refreshQuote = () => {
    setRefreshKey(prev => prev + 1);
  };

  // Handle error state
  if (isError) {
    toast({
      title: "Error fetching quote",
      description: "Failed to load motivational quote. Try refreshing.",
      variant: "destructive",
    });
  }

  return {
    quote,
    refreshQuote,
    isLoading
  };
}
