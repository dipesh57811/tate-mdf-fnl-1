import { create } from "zustand";
import { User } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface AuthState {
  user: User | null;
  isLoading: boolean;
  error: Error | null;
  
  // Fetch the current user
  fetchUser: () => Promise<User | null>;
  
  // Login a user
  login: (username: string, password: string) => Promise<User>;
  
  // Logout the current user
  logout: () => Promise<void>;
  
  // Register a new user
  register: (username: string, password: string) => Promise<User>;
}

// We're using a store for simplicity, but in a real app this would use
// react-query or SWR for better caching and revalidation
export const useAuth = create<AuthState>((set, get) => ({
  user: null,
  isLoading: true,
  error: null,
  
  fetchUser: async () => {
    try {
      set({ isLoading: true, error: null });
      
      const res = await fetch('/api/user');
      
      if (res.status === 401) {
        set({ user: null, isLoading: false });
        return null;
      }
      
      if (!res.ok) {
        throw new Error('Failed to fetch user');
      }
      
      const user = await res.json();
      set({ user, isLoading: false });
      return user;
    } catch (error) {
      set({ error: error as Error, isLoading: false });
      return null;
    }
  },
  
  login: async (username, password) => {
    try {
      set({ isLoading: true, error: null });
      
      const res = await apiRequest('POST', '/api/login', { username, password });
      
      if (!res.ok) {
        throw new Error('Login failed');
      }
      
      const user = await res.json();
      set({ user, isLoading: false });
      return user;
    } catch (error) {
      set({ error: error as Error, isLoading: false });
      throw error;
    }
  },
  
  logout: async () => {
    try {
      set({ isLoading: true, error: null });
      
      const res = await apiRequest('POST', '/api/logout');
      
      if (!res.ok) {
        throw new Error('Logout failed');
      }
      
      set({ user: null, isLoading: false });
    } catch (error) {
      set({ error: error as Error, isLoading: false });
      throw error;
    }
  },
  
  register: async (username, password) => {
    try {
      set({ isLoading: true, error: null });
      
      const res = await apiRequest('POST', '/api/register', { username, password });
      
      if (!res.ok) {
        throw new Error('Registration failed');
      }
      
      const user = await res.json();
      set({ user, isLoading: false });
      return user;
    } catch (error) {
      set({ error: error as Error, isLoading: false });
      throw error;
    }
  }
}));

// Initialize by fetching the user
useAuth.getState().fetchUser();