import React from "react";
import { PremiumRoutine, User } from "@shared/schema";
import { useQuery, useMutation } from "@tanstack/react-query";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { Lock, Unlock, Trophy } from "lucide-react";

interface LockedRoutineProps {
  premiumRoutine: PremiumRoutine;
}

const LockedRoutine: React.FC<LockedRoutineProps> = ({ premiumRoutine }) => {
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['/api/user'],
    queryFn: getQueryFn({ on401: "returnNull" })
  });

  const { data: unlockedRoutines = [], isLoading: routinesLoading } = useQuery({
    queryKey: ['/api/user', user?.id, 'premium-routines'],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: !!user?.id
  });

  const unlockMutation = useMutation({
    mutationFn: async () => {
      if (!user?.id) throw new Error("User not found");
      const result = await apiRequest(`/api/premium-routines/${premiumRoutine.id}/unlock`, {
        method: 'POST',
        body: JSON.stringify({ userId: user.id })
      });
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      queryClient.invalidateQueries({ queryKey: ['/api/user', user?.id, 'premium-routines'] });
      toast({
        title: "Routine Unlocked!",
        description: `You've unlocked the ${premiumRoutine.title} routine.`,
        variant: "default"
      });
    },
    onError: (error: any) => {
      toast({
        title: "Couldn't Unlock Routine",
        description: error.message || "You don't have enough coins for this routine.",
        variant: "destructive"
      });
    }
  });

  const isUnlocked = unlockedRoutines.some((r: PremiumRoutine) => r.id === premiumRoutine.id);
  const canAfford = (user?.coins || 0) >= premiumRoutine.cost;

  const handleUnlock = () => {
    if (!canAfford) {
      toast({
        title: "Not Enough Coins",
        description: `You need ${premiumRoutine.cost} coins to unlock this routine.`,
        variant: "destructive"
      });
      return;
    }
    unlockMutation.mutate();
  };

  if (userLoading || routinesLoading) {
    return <div className="flex items-center justify-center p-6">Loading routine...</div>;
  }

  return (
    <Card className={`border ${isUnlocked ? 'border-green-700 bg-gradient-to-b from-black to-green-950' : 'border-red-800 bg-black'} text-white`}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {isUnlocked ? (
            <Trophy className="w-5 h-5 text-green-500" />
          ) : (
            <Lock className="w-5 h-5 text-red-500" />
          )}
          <span>{premiumRoutine.title}</span>
        </CardTitle>
        <CardDescription className="text-gray-400">{premiumRoutine.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="p-4 rounded-md bg-opacity-20 bg-gray-900">
          <p className="text-sm">{premiumRoutine.details}</p>
        </div>
      </CardContent>
      <CardFooter>
        {isUnlocked ? (
          <Button className="w-full bg-green-700 hover:bg-green-600 text-white cursor-default">
            <Unlock className="mr-2 h-4 w-4" /> Unlocked
          </Button>
        ) : (
          <Button
            onClick={handleUnlock}
            disabled={unlockMutation.isPending || !canAfford}
            className="w-full bg-red-700 hover:bg-red-600 text-white"
          >
            {unlockMutation.isPending ? "Unlocking..." : `Unlock for ${premiumRoutine.cost} Coins`}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default LockedRoutine;