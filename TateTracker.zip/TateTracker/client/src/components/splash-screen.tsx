import React, { useEffect, useState } from "react";
import { useRandomQuote } from "@/hooks/use-quotes";
import maskImage from "@assets/63430fa23ef0a5a03a4a0770_Mask group.png";

interface SplashScreenProps {
  onFinish: () => void;
}

const SplashScreen = ({ onFinish }: SplashScreenProps) => {
  const [fadeOut, setFadeOut] = useState(false);
  const [progress, setProgress] = useState(0);
  const { quote } = useRandomQuote();
  
  const loadingMessages = [
    "Initializing the matrix...",
    "Connecting to the real world...",
    "Loading Tate wisdom...",
    "Breaking free from the matrix...",
    "Preparing your escape plan...",
    "Analyzing your potential..."
  ];

  const [currentMessage, setCurrentMessage] = useState(loadingMessages[0]);
  
  useEffect(() => {
    let messageInterval: NodeJS.Timeout;
    const loadingInterval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + 2;
        if (newProgress >= 100) {
          clearInterval(loadingInterval);
          setFadeOut(true);
          setTimeout(onFinish, 500);
          return 100;
        }
        return newProgress;
      });
    }, 30);

    let messageIndex = 0;
    messageInterval = setInterval(() => {
      messageIndex = (messageIndex + 1) % loadingMessages.length;
      setCurrentMessage(loadingMessages[messageIndex]);
    }, 1500);

    return () => {
      clearInterval(loadingInterval);
      clearInterval(messageInterval);
    };
  }, [onFinish, loadingMessages]);

  return (
    <div
      className={`fixed inset-0 bg-black flex flex-col items-center justify-center z-50 transition-opacity duration-1000 ${
        fadeOut ? "opacity-0" : "opacity-100"
      }`}
    >
      <div className="absolute inset-0 overflow-hidden">
        <div className="matrix-code-rain"></div>
      </div>
      
      <div className="relative z-10 flex flex-col items-center max-w-lg px-4">
        <img 
          src={maskImage} 
          alt="Andrew Tate" 
          className="w-32 h-32 object-cover mb-8 rounded-full border-2 border-red-600 shadow-lg shadow-red-600/50" 
        />
        
        <h1 className="text-4xl font-bold text-red-600 mb-4 text-center">
          THE REAL WORLD
        </h1>
        
        <div className="w-full bg-gray-800 rounded-full h-2.5 mb-6">
          <div 
            className="bg-gradient-to-r from-red-800 to-red-500 h-2.5 rounded-full" 
            style={{ width: `${progress}%` }}
          ></div>
        </div>
        
        <p className="text-gray-300 mb-8 text-center">{currentMessage}</p>
        
        {quote && (
          <div className="bg-black/60 border border-red-800 p-4 rounded-lg max-w-md">
            <p className="text-white italic text-center">"{quote.text}"</p>
            {quote.author && (
              <p className="text-red-500 text-right mt-2">- {quote.author}</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default SplashScreen;