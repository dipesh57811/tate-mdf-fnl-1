import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { insertHabitSchema } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

// Create a habit form schema based on our insertion schema
const habitFormSchema = insertHabitSchema.extend({
  title: z
    .string()
    .min(1, "Habit title is required")
    .max(100, "Title is too long"),
});

type HabitFormValues = z.infer<typeof habitFormSchema>;

interface AddHabitDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const AddHabitDialog = ({ open, onOpenChange }: AddHabitDialogProps) => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initialize form with default values
  const form = useForm<HabitFormValues>({
    resolver: zodResolver(habitFormSchema),
    defaultValues: {
      userId: 1, // Default user
      title: "",
      description: "",
    },
  });

  // Habit create mutation
  const createHabitMutation = useMutation({
    mutationFn: async (data: HabitFormValues) => {
      return apiRequest("POST", "/api/habits", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/habits"] });
      toast({
        title: "Habit created",
        description: "Your habit has been created successfully.",
      });
      form.reset();
      onOpenChange(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create habit. Please try again.",
        variant: "destructive",
      });
      console.error(error);
    },
    onSettled: () => {
      setIsSubmitting(false);
    },
  });

  const onSubmit = (data: HabitFormValues) => {
    setIsSubmitting(true);
    createHabitMutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-gradient-to-b from-secondary to-secondary/90 text-white sm:max-w-[425px] border border-accent/30">
        <DialogHeader>
          <DialogTitle className="text-xl font-['Bebas_Neue'] tracking-wider text-center">
            FORGE NEW HABIT
          </DialogTitle>
          <div className="text-xs text-muted-foreground text-center mt-1">
            The most powerful man is the man who can control himself
          </div>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-accent font-semibold">
                    HABIT TITLE
                  </FormLabel>
                  <FormControl>
                    <Input
                      placeholder="500 Push-ups Challenge or 5 Cups of Coffee a Day"
                      className="border-primary/40 focus:border-accent focus-visible:ring-accent/30"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage className="text-accent" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-accent font-semibold">
                    DESCRIPTION (WHY THIS MATTERS)
                  </FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Did you complete your goal? Track how many you did today!"
                      className="resize-none border-primary/40 focus:border-accent focus-visible:ring-accent/30"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage className="text-accent" />
                </FormItem>
              )}
            />

            <div className="text-xs text-muted-foreground p-2 bg-muted/40 rounded border border-accent/10 mt-2">
              <p className="font-semibold text-accent mb-1">TOP G REMINDER:</p>
              <p>
                Consistency is the key to mastery. Commit to this habit daily
                and watch your life transform.
              </p>
            </div>

            <DialogFooter className="gap-2">
              <DialogClose asChild>
                <Button
                  type="button"
                  variant="outline"
                  className="border-accent/30 hover:bg-accent/10"
                >
                  WEAK MINDSET
                </Button>
              </DialogClose>
              <Button
                type="submit"
                className="bg-accent text-black hover:bg-accent/90 font-bold"
                disabled={isSubmitting}
              >
                {isSubmitting ? "CREATING..." : "COMMIT TO GREATNESS"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

export default AddHabitDialog;
