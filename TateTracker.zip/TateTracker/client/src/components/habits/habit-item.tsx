
import { useState } from "react";
import { Habit } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { CheckCircle, Target } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface HabitItemProps {
  habit: Habit;
}

const HabitItem = ({ habit }: HabitItemProps) => {
  const queryClient = useQueryClient();
  const [isCompleting, setIsCompleting] = useState(false);

  const completeMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/habits/${habit.id}/completions`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/habits"] });
    },
  });

  return (
    <Card className="bg-card">
      <CardContent className="pt-6">
        <h3 className="text-lg font-semibold mb-2">{habit.title}</h3>
        <p className="text-muted-foreground text-sm">{habit.description}</p>
        <div className="mt-4 flex items-center text-sm">
          <Target className="h-4 w-4 mr-2 text-accent" />
          <span>Current Streak: {habit.streak} days</span>
        </div>
      </CardContent>
      <CardFooter>
        <Button 
          className="w-full" 
          onClick={() => completeMutation.mutate()}
          disabled={completeMutation.isPending}
        >
          <CheckCircle className="h-4 w-4 mr-2" />
          Complete Today
        </Button>
      </CardFooter>
    </Card>
  );
};

export default HabitItem;
