import React from "react";
import { User } from "@shared/schema";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Wallet, LightbulbIcon, UserPlus, Gift } from "lucide-react";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";

const WalletDisplay = () => {
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['/api/user'],
    queryFn: getQueryFn({ on401: "returnNull" })
  });

  const earnCoinsMutation = useMutation({
    mutationFn: async () => {
      const result = await apiRequest(`/api/user/${user?.id}/earn-coins`, {
        method: 'POST',
        body: JSON.stringify({ amount: 10 })
      });
      return result as User;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      toast({
        title: "Coins Earned!",
        description: `You've earned 10 TRW Coins! Your new balance: ${data?.coins}`,
        variant: "default"
      });
    }
  });

  const handleEarnCoins = () => {
    earnCoinsMutation.mutate();
  };

  if (userLoading) {
    return <div className="flex items-center justify-center p-6">Loading wallet...</div>;
  }

  return (
    <div className="text-white">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-2xl font-bold text-accent">
          <Wallet className="w-6 h-6 text-accent" />
          <span>YOUR TRW COINS: <span className="text-white">{user?.coins || 0}</span></span>
        </CardTitle>
        <CardDescription className="text-muted-foreground">Check Balance & Earn More!</CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="bg-gradient-to-r from-background to-secondary p-4 rounded-md border border-accent/20">
          <div className="flex items-center space-x-3 w-full">
            <LightbulbIcon className="h-5 w-5 text-accent flex-shrink-0" />
            <div className="w-full">
              <Button 
                onClick={handleEarnCoins}
                disabled={earnCoinsMutation.isPending} 
                className="bg-accent text-black hover:bg-accent/90 font-bold w-full"
              >
                {earnCoinsMutation.isPending ? "EARNING..." : "💡 WATCH AN AD & EARN MORE COINS!"}
              </Button>
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-background to-secondary p-4 rounded-md border border-accent/20">
          <div className="flex items-center space-x-3 w-full">
            <UserPlus className="h-5 w-5 text-accent flex-shrink-0" />
            <div className="w-full">
              <Button className="bg-accent text-black hover:bg-accent/90 font-bold w-full">
                INVITE FRIENDS & GET BONUS COINS!
              </Button>
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-background to-secondary p-4 rounded-md border border-accent/20">
          <div className="flex items-center space-x-3 w-full">
            <Gift className="h-5 w-5 text-accent flex-shrink-0" />
            <div className="w-full">
              <Button className="bg-accent/80 text-black hover:bg-accent/90 font-bold w-full">
                USE COINS TO UNLOCK SPECIAL REWARDS!
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </div>
  );
};

export default WalletDisplay;
