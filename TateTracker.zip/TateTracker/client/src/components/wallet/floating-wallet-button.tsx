import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { CoinsIcon } from "lucide-react";
import WalletDisplay from "./wallet-display";
import {
  Dialog,
  DialogContent
} from "@/components/ui/dialog";

const FloatingWalletButton = () => {
  const [isWalletOpen, setIsWalletOpen] = useState(false);

  return (
    <>
      {/* Wallet Button Positioned in Bottom-Right Corner */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsWalletOpen(true)}
          className="w-14 h-14 rounded-full bg-gradient-to-r from-yellow-500 to-yellow-400 text-black shadow-lg hover:shadow-xl hover:bg-yellow-500/90 transition-all duration-300 flex flex-col items-center justify-center p-0 border-2 border-yellow-400"
        >
          <CoinsIcon className="h-5 w-5 mb-1" />
          <span className="text-[10px] font-semibold">💰 TRW Wallet</span>
        </Button>
      </div>

      {/* Wallet Dialog - Opens when user clicks */}
      <Dialog open={isWalletOpen} onOpenChange={setIsWalletOpen}>
        <DialogContent className="bg-gradient-to-b from-gray-900 to-gray-800 border border-yellow-500 text-white sm:max-w-[400px] rounded-xl shadow-xl p-5">
          <h2 className="text-xl font-bold text-yellow-400 text-center mb-4">Your TRW Wallet</h2>
          <WalletDisplay />
          <div className="text-center mt-4">
            <Button 
              className="bg-yellow-500 text-black px-4 py-2 rounded-lg hover:bg-yellow-400 transition-all"
              onClick={() => setIsWalletOpen(false)}
            >
              Close Wallet
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default FloatingWalletButton;
