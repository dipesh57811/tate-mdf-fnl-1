import { Video, VideoCategories } from '@shared/schema';
import { VideoCard } from './video-card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface VideosGridProps {
  videos: Video[];
  title?: string;
}

export function VideosGrid({ videos, title }: VideosGridProps) {
  // Group videos by category
  const videosByCategory: Record<string, Video[]> = {
    all: videos,
  };
  
  // Create category lists
  for (const category of Object.values(VideoCategories)) {
    videosByCategory[category] = videos.filter(video => video.category === category);
  }
  
  return (
    <div className="space-y-6">
      {title && <h2 className="text-2xl font-bold text-white">{title}</h2>}
      
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="bg-black border border-red-800 mb-4">
          <TabsTrigger 
            value="all" 
            className="data-[state=active]:bg-red-700 data-[state=active]:text-white"
          >
            All Videos
          </TabsTrigger>
          
          {Object.values(VideoCategories).map(category => (
            <TabsTrigger 
              key={category}
              value={category}
              className="data-[state=active]:bg-red-700 data-[state=active]:text-white"
            >
              {category.replace('TATE_', '').replace('_', ' ')}
            </TabsTrigger>
          ))}
        </TabsList>
        
        <TabsContent value="all" className="mt-0">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {videos.length > 0 ? (
              videos.map(video => (
                <VideoCard key={video.id} video={video} />
              ))
            ) : (
              <div className="col-span-full text-center py-12 text-gray-400">
                No videos available
              </div>
            )}
          </div>
        </TabsContent>
        
        {Object.entries(VideoCategories).map(([key, category]) => (
          <TabsContent key={category} value={category} className="mt-0">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {videosByCategory[category] && videosByCategory[category].length > 0 ? (
                videosByCategory[category].map(video => (
                  <VideoCard key={video.id} video={video} />
                ))
              ) : (
                <div className="col-span-full text-center py-12 text-gray-400">
                  No {category.replace('TATE_', '').replace('_', ' ')} videos available
                </div>
              )}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}