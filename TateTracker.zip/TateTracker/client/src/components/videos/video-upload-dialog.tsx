import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { insertVideoSchema, VideoCategories } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, Upload } from 'lucide-react';

interface VideoUploadDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

// Create a form schema based on the video insert schema
const videoFormSchema = insertVideoSchema.pick({
  title: true,
  description: true,
  category: true,
  videoUrl: true,
}).extend({
  title: z.string().min(3, "Title must be at least 3 characters").max(100, "Title is too long"),
  description: z.string().min(10, "Description must be at least 10 characters").max(500, "Description is too long"),
  // For demo purposes, we'll use a URL field instead of actual file upload
  videoUrl: z.string().url("Please enter a valid video URL"),
  thumbnailUrl: z.string().url("Please enter a valid thumbnail URL").optional().or(z.literal("")),
  // For simplicity, we'll make duration optional and format it on the server
  duration: z.string().optional().or(z.literal("")),
});

type VideoFormValues = z.infer<typeof videoFormSchema>;

export function VideoUploadDialog({ open, onOpenChange }: VideoUploadDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isUploading, setIsUploading] = useState(false); // Simulate upload progress
  
  // Initialize form with default values
  const form = useForm<VideoFormValues>({
    resolver: zodResolver(videoFormSchema),
    defaultValues: {
      title: '',
      description: '',
      category: 'TATE_EDIT', // Default category
      videoUrl: '',
      thumbnailUrl: '',
      duration: '',
    }
  });
  
  // Create mutation for uploading video
  const { mutate: uploadVideo, isPending } = useMutation({
    mutationFn: async (data: VideoFormValues) => {
      // Simulate upload progress
      setIsUploading(true);
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Format data before sending to API
      const apiData = {
        ...data,
        // Generate a duration if not provided
        duration: data.duration || "03:45",
      };
      
      const response = await apiRequest('/api/videos', {
        method: 'POST',
        body: JSON.stringify(apiData),
      });
      
      // After successful video upload, send notification via WebSocket API
      if (response && response.id) {
        await apiRequest(`/api/videos/${response.id}/notify`, {
          method: 'POST',
          body: JSON.stringify({
            title: data.title,
            category: data.category,
          }),
        });
      }
      
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
      toast({
        title: "Video uploaded!",
        description: "Your video has been uploaded successfully",
      });
      form.reset();
      onOpenChange(false);
      setIsUploading(false);
    },
    onError: (error) => {
      toast({
        title: "Upload failed",
        description: "There was an error uploading your video. Please try again.",
        variant: "destructive",
      });
      setIsUploading(false);
    }
  });
  
  // Handle form submission
  const onSubmit = (data: VideoFormValues) => {
    uploadVideo(data);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-black border-red-900 text-white sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-white">Upload Tate Video</DialogTitle>
          <DialogDescription className="text-gray-400">
            Share your favorite Tate content with the community. Earn coins based on views.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-white">Title</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter video title" 
                      className="bg-black border-gray-700 text-white focus:border-red-500"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-white">Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Enter video description" 
                      className="bg-black border-gray-700 text-white focus:border-red-500 resize-none"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-white">Category</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="bg-black border-gray-700 text-white focus:border-red-500">
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent className="bg-black border-gray-700 text-white">
                      {Object.entries(VideoCategories).map(([key, value]) => (
                        <SelectItem key={value} value={value} className="focus:bg-red-900">
                          {value.replace('TATE_', '').replace('_', ' ')}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="videoUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-white">Video URL</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter video URL" 
                      className="bg-black border-gray-700 text-white focus:border-red-500"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="thumbnailUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-white">Thumbnail URL (Optional)</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter thumbnail URL" 
                      className="bg-black border-gray-700 text-white focus:border-red-500"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="duration"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-white">Duration (Optional)</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Format: MM:SS (e.g. 03:45)" 
                      className="bg-black border-gray-700 text-white focus:border-red-500"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => onOpenChange(false)}
                className="bg-transparent border-gray-700 text-white hover:bg-gray-800"
                disabled={isPending || isUploading}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="bg-red-600 hover:bg-red-700 text-white"
                disabled={isPending || isUploading}
              >
                {(isPending || isUploading) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {(isPending || isUploading) ? "Uploading..." : "Upload Video"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}