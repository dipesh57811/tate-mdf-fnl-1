import React, { useState, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { storage } from '../../firebaseConfig';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { VideoCategories } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Plus, Upload } from 'lucide-react';

interface UploadVideoProps {
  onUploadSuccess?: (videoId: number) => void;
}

const AdminVideoUpload: React.FC<UploadVideoProps> = ({ onUploadSuccess }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<string>(VideoCategories.TATE_SHORT);
  const [file, setFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [isOfficial, setIsOfficial] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const thumbnailInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Fetch user data to check if admin
  const { data: user } = useQuery({
    queryKey: ['/api/user'],
  });

  // Check if user is admin (id === 1)
  const isAdmin = user && user.id === 1;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleThumbnailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setThumbnailFile(file);
      
      // Create thumbnail preview
      const reader = new FileReader();
      reader.onload = (e) => {
        setThumbnailPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setCategory(VideoCategories.TATE_SHORT);
    setFile(null);
    setThumbnailFile(null);
    setThumbnailPreview(null);
    setUploadProgress(0);
    setIsUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (thumbnailInputRef.current) thumbnailInputRef.current.value = '';
  };

  const uploadVideo = async () => {
    if (!file) {
      toast({
        title: "No video selected",
        description: "Please select a video file to upload",
        variant: "destructive",
      });
      return;
    }

    if (!title) {
      toast({
        title: "Title is required",
        description: "Please enter a title for your video",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    
    try {
      // Upload video to Firebase Storage
      const videoFileName = `videos/${Date.now()}_${file.name}`;
      const videoStorageRef = ref(storage, videoFileName);
      const videoUploadTask = uploadBytesResumable(videoStorageRef, file);

      videoUploadTask.on(
        'state_changed',
        (snapshot) => {
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          setUploadProgress(progress);
        },
        (error) => {
          console.error('Error uploading video:', error);
          toast({
            title: "Upload failed",
            description: "There was an error uploading your video",
            variant: "destructive",
          });
          setIsUploading(false);
        },
        async () => {
          // Get video download URL
          const videoUrl = await getDownloadURL(videoUploadTask.snapshot.ref);
          let thumbnailUrl = '';

          // Upload thumbnail if provided
          if (thumbnailFile) {
            const thumbnailFileName = `thumbnails/${Date.now()}_${thumbnailFile.name}`;
            const thumbnailStorageRef = ref(storage, thumbnailFileName);
            const thumbnailUploadTask = uploadBytesResumable(thumbnailStorageRef, thumbnailFile);
            
            await thumbnailUploadTask;
            thumbnailUrl = await getDownloadURL(thumbnailUploadTask.snapshot.ref);
          }

          // Create video entry in the database
          const response = await apiRequest('POST', '/api/videos', {
            title,
            description,
            url: videoUrl,
            thumbnailUrl: thumbnailUrl || null,
            category,
            isOfficial,
          });

          if (response.ok) {
            const data = await response.json();
            toast({
              title: "Upload successful",
              description: "Your video has been uploaded successfully",
            });
            
            // Invalidate videos query to refresh list
            queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
            
            if (onUploadSuccess) {
              onUploadSuccess(data.id);
            }
            
            resetForm();
            setOpen(false);
          } else {
            throw new Error('Failed to save video entry');
          }
          
          setIsUploading(false);
        }
      );
    } catch (error) {
      console.error('Error in video upload process:', error);
      toast({
        title: "Upload failed",
        description: "There was an error processing your video",
        variant: "destructive",
      });
      setIsUploading(false);
    }
  };

  // If not admin, don't render the component
  if (!isAdmin) {
    return null;
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-red-800 hover:bg-red-700">
          <Plus className="mr-2 h-4 w-4" />
          Upload New Video
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] bg-gray-900 text-white border-red-800">
        <DialogHeader>
          <DialogTitle className="text-red-500 font-bold">Upload Tate Video</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <Input
            id="title"
            placeholder="Video Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="bg-gray-800 border-gray-700"
          />
          
          <Textarea
            id="description"
            placeholder="Video Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="bg-gray-800 border-gray-700"
          />
          
          <div className="flex flex-col gap-2">
            <label htmlFor="category" className="text-sm text-gray-400">Category</label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="bg-gray-800 border-gray-700">
                <SelectValue placeholder="Select Category" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700">
                {Object.values(VideoCategories).map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat.replace('tate_', '').toUpperCase()}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex flex-col gap-2">
            <label className="text-sm text-gray-400">Video File</label>
            <div className="flex items-center gap-2">
              <Input
                ref={fileInputRef}
                id="video-file"
                type="file"
                accept="video/*"
                onChange={handleFileChange}
                className="bg-gray-800 border-gray-700"
              />
              {file && (
                <span className="text-xs text-gray-400 truncate max-w-[150px]">
                  {file.name}
                </span>
              )}
            </div>
          </div>
          
          <div className="flex flex-col gap-2">
            <label className="text-sm text-gray-400">Thumbnail (Optional)</label>
            <div className="flex items-center gap-2">
              <Input
                ref={thumbnailInputRef}
                id="thumbnail-file"
                type="file"
                accept="image/*"
                onChange={handleThumbnailChange}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            {thumbnailPreview && (
              <Card className="mt-2 overflow-hidden bg-gray-800 border-gray-700">
                <CardContent className="p-0">
                  <img
                    src={thumbnailPreview}
                    alt="Thumbnail preview"
                    className="w-full h-auto object-cover max-h-32"
                  />
                </CardContent>
              </Card>
            )}
          </div>
          
          <div className="flex items-center">
            <input
              type="checkbox"
              id="official"
              checked={isOfficial}
              onChange={(e) => setIsOfficial(e.target.checked)}
              className="mr-2"
            />
            <label htmlFor="official" className="text-sm text-gray-400">
              Mark as Official Tate Content
            </label>
          </div>
          
          {isUploading && (
            <div className="flex flex-col gap-1">
              <span className="text-xs text-gray-400">Uploading: {Math.round(uploadProgress)}%</span>
              <Progress value={uploadProgress} className="h-2 bg-gray-700" />
            </div>
          )}
        </div>
        
        <DialogFooter>
          <Button
            type="button"
            onClick={resetForm}
            variant="outline"
            className="border-gray-700 text-gray-300"
            disabled={isUploading}
          >
            Cancel
          </Button>
          <Button
            type="button"
            onClick={uploadVideo}
            className="bg-red-800 hover:bg-red-700"
            disabled={isUploading || !file}
          >
            {isUploading ? (
              <>
                <Upload className="mr-2 h-4 w-4 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="mr-2 h-4 w-4" />
                Upload
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AdminVideoUpload;