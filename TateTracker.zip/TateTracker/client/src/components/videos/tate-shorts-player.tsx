import React, { useState, useRef, useEffect } from 'react';
import { Video } from '@shared/schema';
import { Heart, MessageCircle, Share, ChevronUp, ChevronDown, User } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { queryClient } from '@/lib/queryClient';
import { formatDistanceToNow } from 'date-fns';

interface TateShortPlayerProps {
  videos: Video[];
  initialVideoIndex?: number;
}

const TateShortPlayer: React.FC<TateShortPlayerProps> = ({ 
  videos, 
  initialVideoIndex = 0 
}) => {
  const [currentVideoIndex, setCurrentVideoIndex] = useState(initialVideoIndex);
  const [isPlaying, setIsPlaying] = useState(false);
  const [muted, setMuted] = useState(true);
  const [interacted, setInteracted] = useState(false);
  const videoRefs = useRef<(HTMLVideoElement | null)[]>([]);
  const playerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  const currentVideo = videos[currentVideoIndex];
  
  useEffect(() => {
    // Initialize video references
    videoRefs.current = videoRefs.current.slice(0, videos.length);
    
    // Observer for intersection
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const video = entry.target as HTMLVideoElement;
            if (interacted) {
              video.play().catch(err => console.error("Couldn't play video:", err));
              setIsPlaying(true);
            }
          } else {
            const video = entry.target as HTMLVideoElement;
            video.pause();
            setIsPlaying(false);
          }
        });
      },
      { threshold: 0.7 }
    );
    
    // Observe current video
    if (videoRefs.current[currentVideoIndex]) {
      observer.observe(videoRefs.current[currentVideoIndex]!);
    }
    
    return () => {
      // Cleanup
      if (videoRefs.current[currentVideoIndex]) {
        observer.unobserve(videoRefs.current[currentVideoIndex]!);
      }
    };
  }, [currentVideoIndex, videos.length, interacted]);

  const handleVideoClick = () => {
    if (!interacted) {
      setInteracted(true);
    }
    
    const videoElement = videoRefs.current[currentVideoIndex];
    if (videoElement) {
      if (isPlaying) {
        videoElement.pause();
        setIsPlaying(false);
      } else {
        videoElement.play().catch(err => console.error("Couldn't play video:", err));
        setIsPlaying(true);
      }
    }
  };

  const handleMuteToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    setMuted(!muted);
  };

  const handleNextVideo = () => {
    if (currentVideoIndex < videos.length - 1) {
      setCurrentVideoIndex(currentVideoIndex + 1);
    }
  };

  const handlePrevVideo = () => {
    if (currentVideoIndex > 0) {
      setCurrentVideoIndex(currentVideoIndex - 1);
    }
  };

  const handleLike = async (e: React.MouseEvent, videoId: number) => {
    e.stopPropagation();
    try {
      await apiRequest('PATCH', `/api/videos/${videoId}/like`);
      // Invalidate the video query to refetch the latest like count
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
      queryClient.invalidateQueries({ queryKey: [`/api/videos/${videoId}`] });
      toast({
        title: "Liked!",
        description: "You liked this video"
      });
    } catch (error) {
      console.error('Error liking video:', error);
      toast({
        title: "Error",
        description: "Failed to like the video",
        variant: "destructive"
      });
    }
  };

  // Track when video is viewed at least 50%
  const handleTimeUpdate = (videoId: number) => {
    const videoElement = videoRefs.current[currentVideoIndex];
    if (videoElement) {
      const percentViewed = (videoElement.currentTime / videoElement.duration) * 100;
      if (percentViewed >= 50) {
        // Only record a view once per session
        const viewedVideos = JSON.parse(sessionStorage.getItem('viewedVideos') || '[]');
        if (!viewedVideos.includes(videoId)) {
          viewedVideos.push(videoId);
          sessionStorage.setItem('viewedVideos', JSON.stringify(viewedVideos));
          
          // Only need to call this once, when we reach 50%
          videoElement.removeEventListener('timeupdate', () => handleTimeUpdate(videoId));
        }
      }
    }
  };

  if (!videos.length) {
    return (
      <div className="flex items-center justify-center h-screen bg-black">
        <p className="text-white">No videos available</p>
      </div>
    );
  }

  return (
    <div 
      ref={playerRef} 
      className="relative w-full h-full max-h-screen bg-black overflow-hidden"
    >
      <div className="w-full h-full relative">
        {videos.map((video, index) => (
          <div 
            key={video.id}
            className={`absolute inset-0 transition-opacity duration-300 ${
              index === currentVideoIndex ? 'opacity-100 z-10' : 'opacity-0 -z-10'
            }`}
          >
            <video
              ref={el => videoRefs.current[index] = el}
              src={video.url}
              poster={video.thumbnailUrl || undefined}
              loop
              playsInline
              muted={muted}
              className="w-full h-full object-contain"
              onClick={handleVideoClick}
              onTimeUpdate={() => handleTimeUpdate(video.id)}
            />
            
            {/* Video Info Overlay */}
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/90 to-transparent">
              <div className="flex items-start space-x-2">
                <div className="w-10 h-10 rounded-full bg-red-800 flex items-center justify-center">
                  <User className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white font-bold truncate">{video.title}</h3>
                  <p className="text-gray-300 text-sm truncate">
                    {formatDistanceToNow(new Date(video.createdAt), { addSuffix: true })}
                  </p>
                  <p className="text-gray-400 text-sm mt-1 line-clamp-2">
                    {video.description}
                  </p>
                </div>
              </div>
            </div>
            
            {/* Interaction Buttons */}
            <div className="absolute right-4 bottom-20 flex flex-col items-center space-y-6">
              <button 
                onClick={(e) => handleLike(e, video.id)}
                className="bg-transparent rounded-full p-2 text-white hover:bg-red-800/20 transition"
              >
                <Heart className="w-8 h-8" />
                <span className="text-sm">{video.likes}</span>
              </button>
              
              <button className="bg-transparent rounded-full p-2 text-white hover:bg-red-800/20 transition">
                <MessageCircle className="w-8 h-8" />
                <span className="text-sm">{video.comments || 0}</span>
              </button>
              
              <button className="bg-transparent rounded-full p-2 text-white hover:bg-red-800/20 transition">
                <Share className="w-8 h-8" />
              </button>
              
              <button
                onClick={handleMuteToggle}
                className="bg-transparent rounded-full p-2 text-white hover:bg-red-800/20 transition"
              >
                {muted ? (
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-8 h-8">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" />
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-8 h-8">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                  </svg>
                )}
              </button>
            </div>
          </div>
        ))}
        
        {/* Navigation Controls */}
        <button 
          onClick={handlePrevVideo}
          disabled={currentVideoIndex === 0}
          className={`absolute top-1/4 left-4 transform -translate-y-1/2 bg-black/20 rounded-full p-2 ${
            currentVideoIndex === 0 ? 'opacity-30 cursor-not-allowed' : 'opacity-70 hover:opacity-100'
          }`}
        >
          <ChevronUp className="w-6 h-6 text-white" />
        </button>
        
        <button 
          onClick={handleNextVideo}
          disabled={currentVideoIndex === videos.length - 1}
          className={`absolute bottom-1/4 left-4 transform translate-y-1/2 bg-black/20 rounded-full p-2 ${
            currentVideoIndex === videos.length - 1 ? 'opacity-30 cursor-not-allowed' : 'opacity-70 hover:opacity-100'
          }`}
        >
          <ChevronDown className="w-6 h-6 text-white" />
        </button>
        
        {/* Play/Pause Indicator */}
        {!interacted && (
          <div 
            className="absolute inset-0 flex items-center justify-center bg-black/30 z-20 cursor-pointer"
            onClick={() => setInteracted(true)}
          >
            <div className="bg-red-800 rounded-full p-4 animate-pulse">
              <svg xmlns="http://www.w3.org/2000/svg" fill="white" viewBox="0 0 24 24" className="w-12 h-12">
                <path d="M8 5v14l11-7z" />
              </svg>
            </div>
            <p className="absolute bottom-1/4 text-white text-lg font-bold">Tap to play</p>
          </div>
        )}
        
        {interacted && !isPlaying && (
          <div 
            className="absolute inset-0 flex items-center justify-center bg-black/10 z-0 cursor-pointer"
            onClick={handleVideoClick}
          >
            <div className="bg-red-800/80 rounded-full p-4">
              <svg xmlns="http://www.w3.org/2000/svg" fill="white" viewBox="0 0 24 24" className="w-12 h-12">
                <path d="M8 5v14l11-7z" />
              </svg>
            </div>
          </div>
        )}
      </div>
      
      {/* Video Progress Indicator */}
      <div className="absolute top-0 left-0 right-0 flex justify-evenly px-2 pt-1">
        {videos.map((_, index) => (
          <div 
            key={index}
            className={`h-1 flex-1 mx-1 rounded-full ${
              index === currentVideoIndex ? 'bg-red-500' : 
              index < currentVideoIndex ? 'bg-gray-400' : 'bg-gray-700'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export default TateShortPlayer;