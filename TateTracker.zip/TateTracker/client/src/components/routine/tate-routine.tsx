import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getCategoryColors } from "@/lib/utils";

const tateRoutine = [
  { time: "06:30 AM", activity: "Wake Up" },
  { time: "06:35 AM", activity: "Coffee #1 (Black Coffee)" },
  { time: "06:45 AM", activity: "Emails & Work" },
  { time: "07:30 AM", activity: "Cigar / Meditation" },
  { time: "08:00 AM", activity: "Workout (Strength + Cardio)" },
  { time: "09:00 AM", activity: "Cold Shower" },
  { time: "09:15 AM", activity: "Breakfast (High-Protein)" },
  { time: "10:00 AM", activity: "Business & Meetings" },
  { time: "11:30 AM", activity: "Coffee #2 (Espresso)" },
  { time: "12:00 PM", activity: "Drive / Relax" },
  { time: "01:00 PM", activity: "Lunch (Steak, Chicken, Salad)" },
  { time: "02:00 PM", activity: "Content Creation / Work" },
  { time: "04:00 PM", activity: "Coffee #3 (Americano)" },
  { time: "04:30 PM", activity: "Workout #2 / Kickboxing" },
  { time: "06:00 PM", activity: "Cigar & Relaxing" },
  { time: "07:00 PM", activity: "Dinner (High-Protein, Healthy Fats)" },
  { time: "08:00 PM", activity: "Networking / Socializing" },
  { time: "09:30 PM", activity: "Coffee #4 (Occasional)" },
  { time: "10:00 PM", activity: "Entertainment (Chess, Netflix, Gaming)" },
  { time: "11:00 PM", activity: "Night Shower" },
  { time: "11:30 PM", activity: "Work / Planning" },
  { time: "12:30 AM", activity: "Sleep (6-7 Hours)" },
];

// Categories for the routine items for visual grouping
const getRoutineCategory = (activity: string): string => {
  if (activity.includes("Coffee") || activity.includes("Breakfast") || 
      activity.includes("Lunch") || activity.includes("Dinner")) {
    return "Nutrition";
  } else if (activity.includes("Workout") || activity.includes("Shower")) {
    return "Fitness";
  } else if (activity.includes("Work") || activity.includes("Business") || 
            activity.includes("Content") || activity.includes("Email") || 
            activity.includes("Planning")) {
    return "Work";
  } else if (activity.includes("Relax") || activity.includes("Cigar") || 
            activity.includes("Entertainment") || activity.includes("Sleep") || 
            activity.includes("Meditation")) {
    return "Relaxation";
  } else if (activity.includes("Networking") || activity.includes("Socializing")) {
    return "Social";
  }
  return "Other";
};

const TateRoutine = () => (
  <div className="space-y-6">
    <Card className="bg-gradient-to-r from-primary/20 to-accent/20 border border-accent/30 p-6">
      <h2 className="text-2xl font-montserrat font-bold mb-3">🔥 Andrew Tate Daily Routine 🔥</h2>
      <p className="text-muted-foreground mb-4">
        "Follow this routine exactly to build the discipline of a champion. No excuses, no compromises."
      </p>
    </Card>
    
    <div className="bg-secondary rounded-lg p-4">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mb-3 px-3 font-bold">
        <div className="md:col-span-2">Time</div>
        <div className="md:col-span-6">Activity</div>
        <div className="md:col-span-4">Category</div>
      </div>
      
      <div className="space-y-2">
        {tateRoutine.map((item, index) => {
          const category = getRoutineCategory(item.activity);
          const colors = getCategoryColors(category);
          
          return (
            <div 
              key={index} 
              className="grid grid-cols-1 md:grid-cols-12 gap-4 bg-muted rounded-md p-3 items-center"
            >
              <div className="md:col-span-2 font-medium">{item.time}</div>
              <div className="md:col-span-6">{item.activity}</div>
              <div className="md:col-span-4">
                <Badge className={`${colors.bg} ${colors.text}`}>
                  {category}
                </Badge>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  </div>
);

export default TateRoutine;