import { ReactNode, useEffect } from 'react';
import { useAuth } from '@/hooks/use-auth';

type AuthProviderProps = {
  children: ReactNode;
};

export function AuthProvider({ children }: AuthProviderProps) {
  const { fetchUser } = useAuth();

  // Initialize by fetching the user
  useEffect(() => {
    fetchUser();
  }, [fetchUser]);

  return <>{children}</>;
}