import React, { useEffect, useState } from 'react';
import { useLocation, useRoute } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Shield, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

// Admin roles - in a real app, this would be more sophisticated
const ADMIN_ROLES = ['admin'];

interface AdminGuardProps {
  children: React.ReactNode;
}

const AdminGuard: React.FC<AdminGuardProps> = ({ children }) => {
  const [, setLocation] = useLocation();
  const [isAuthorized, setIsAuthorized] = useState<boolean | null>(null);
  const { toast } = useToast();
  
  // Get the current user
  const { data: user, isLoading } = useQuery({
    queryKey: ['/api/user'],
  });

  // Check if user has admin access
  useEffect(() => {
    if (!isLoading) {
      // In a real app, we would check for an admin role
      // For this demo, only the user with ID 1 is admin
      const hasAccess = user && user.id === 1;
      
      setIsAuthorized(hasAccess);
      
      if (hasAccess === false) {
        toast({
          variant: "destructive",
          title: "Access Denied",
          description: "You don't have permission to access the admin panel.",
        });
        
        // Redirect after a short delay
        setTimeout(() => {
          setLocation('/');
        }, 1500);
      }
    }
  }, [user, isLoading, setLocation, toast]);

  // Show loading state
  if (isLoading || isAuthorized === null) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Shield className="h-12 w-12 mx-auto mb-4 text-red-500 animate-pulse" />
          <h2 className="text-xl font-bold mb-2">Checking permissions...</h2>
          <p className="text-gray-400">Verifying your admin access</p>
        </div>
      </div>
    );
  }

  // Access denied view should never render because of the redirect,
  // but included for completeness
  if (!isAuthorized) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center max-w-md p-6 bg-gray-900 rounded-lg">
          <AlertTriangle className="h-12 w-12 mx-auto mb-4 text-red-500" />
          <h2 className="text-xl font-bold mb-2">Access Denied</h2>
          <p className="text-gray-400 mb-4">
            You don't have permission to access this area. This page is restricted to administrators only.
          </p>
          <Button 
            onClick={() => setLocation('/')}
            className="bg-red-800 hover:bg-red-700"
          >
            Return to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  // User is authorized, render children
  return <>{children}</>;
};

export default AdminGuard;