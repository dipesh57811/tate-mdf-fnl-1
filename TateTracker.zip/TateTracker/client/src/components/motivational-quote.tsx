import React, { useEffect } from "react";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import knightLogo from "../assets/knight-logo.png";
import { getRandomTateQuote } from "@/lib/quotes-service";

const MotivationalQuote = () => {
  useEffect(() => {
    const interval = setInterval(() => {
      toast.info(getRandomTateQuote(), {
        icon: () => (
          <img src={knightLogo} className="w-6 h-6 mr-2" alt="Knight Logo" />
        ),
        autoClose: 5000,
      });
    }, 60000); // 1 minute for demo purposes, change to 3600000 (1 hour) for production

    // Show one immediately on mount
    toast.info(getRandomTateQuote(), {
      icon: () => (
        <img src={knightLogo} className="w-6 h-6 mr-2" alt="Knight Logo" />
      ),
      autoClose: 5000,
    });

    return () => clearInterval(interval);
  }, []);

  return null;
};

export default MotivationalQuote;
