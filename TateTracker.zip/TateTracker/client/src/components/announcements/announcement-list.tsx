import React, { useEffect, useState } from 'react';
import { BellRing, ExternalLink } from 'lucide-react';
import { format } from 'date-fns';

interface Announcement {
  id: number;
  title: string;
  content: string;
  type: string;
  isActive: boolean;
  isPinned: boolean;
  createdAt: string;
  updatedAt: string;
}

interface AnnouncementListProps {
  limit?: number;
}

export const AnnouncementList: React.FC<AnnouncementListProps> = ({ limit }) => {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchAnnouncements = async () => {
      try {
        const response = await fetch('/api/announcements/active');
        if (response.ok) {
          const data = await response.json();
          
          // Sort pinned announcements first
          const sortedAnnouncements = [...data].sort((a, b) => {
            if (a.isPinned && !b.isPinned) return -1;
            if (!a.isPinned && b.isPinned) return 1;
            return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
          });
          
          setAnnouncements(limit ? sortedAnnouncements.slice(0, limit) : sortedAnnouncements);
        }
      } catch (error) {
        console.error('Failed to fetch announcements:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchAnnouncements();
  }, [limit]);

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-3">
        <div className="h-6 bg-gray-800 rounded w-3/4"></div>
        <div className="h-4 bg-gray-800 rounded w-full"></div>
        <div className="h-4 bg-gray-800 rounded w-5/6"></div>
      </div>
    );
  }

  if (announcements.length === 0) {
    return (
      <div className="text-center p-4 bg-gray-900 rounded-lg">
        <BellRing className="mx-auto h-8 w-8 text-gray-400 mb-2" />
        <p className="text-gray-400">No announcements at this time.</p>
      </div>
    );
  }

  // Helper function to get the badge style based on type
  const getTypeBadgeStyle = (type: string) => {
    switch (type) {
      case 'URGENT':
        return 'bg-red-900 text-red-200';
      case 'UPDATE':
        return 'bg-blue-900 text-blue-200';
      case 'JOB':
        return 'bg-green-900 text-green-200';
      case 'PROMOTION':
        return 'bg-yellow-900 text-yellow-200';
      default:
        return 'bg-gray-800 text-gray-200';
    }
  };

  return (
    <div className="space-y-4">
      {announcements.map((announcement) => (
        <div 
          key={announcement.id} 
          className={`p-4 rounded-lg bg-gray-900 border-l-4 ${
            announcement.isPinned ? 'border-yellow-600' : 'border-gray-700'
          } hover:bg-gray-800 transition-colors`}
        >
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-bold text-white">{announcement.title}</h3>
                {announcement.isPinned && (
                  <span className="bg-yellow-600 text-xs px-2 py-0.5 rounded font-medium text-black">
                    PINNED
                  </span>
                )}
                <span className={`text-xs px-2 py-0.5 rounded font-medium ${getTypeBadgeStyle(announcement.type)}`}>
                  {announcement.type}
                </span>
              </div>
              <p className="text-gray-300 text-sm mb-2">{announcement.content}</p>
              <div className="flex items-center text-xs text-gray-400">
                <span>
                  {format(new Date(announcement.createdAt), 'MMMM d, yyyy')}
                </span>
                {/* You could add a link here if announcements have details pages */}
                {false && (
                  <a 
                    href={`/announcements/${announcement.id}`} 
                    className="ml-4 flex items-center text-red-400 hover:text-red-300"
                  >
                    View details <ExternalLink size={12} className="ml-1" />
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default AnnouncementList;