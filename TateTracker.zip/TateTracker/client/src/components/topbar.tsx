import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { SearchIcon, BellIcon, ListChecks } from "lucide-react";
import knightLogo from "../assets/knight-logo.png";

const Topbar = () => {
  const [isMobile, setIsMobile] = useState(false);

  // Check if mobile on mount and when window resizes
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    checkIfMobile();
    window.addEventListener("resize", checkIfMobile);

    return () => {
      window.removeEventListener("resize", checkIfMobile);
    };
  }, []);

  // Get user (in a real app this would include auth)
  const { data: user } = useQuery({
    queryKey: ['/api/user']
  });

  return (
    <header className="glass-card border-b border-border/30 p-4 sticky top-0 z-50">
      <div className="w-full flex justify-between items-center">
        {/* Only show the logo on mobile since it's visible in the sidebar on desktop */}
        <div className="md:hidden flex items-center ml-8">
          <div className="w-10 h-10 flex items-center justify-center">
            <img src={knightLogo} alt="Knight Logo" className="w-full h-full object-contain" />
          </div>
          <h1 className="text-lg ml-2 font-montserrat font-bold text-accent">
            TOP G <span className="text-white">TASKS</span>
          </h1>
        </div>

        <div className="flex ml-auto items-center space-x-4">
          {/* Search bar - only on desktop */}
          <div className="hidden md:flex items-center bg-muted rounded-lg p-2">
            <SearchIcon className="text-muted-foreground h-4 w-4 mr-2" />
            <Input 
              type="text" 
              placeholder="Search..." 
              className="bg-transparent border-none outline-none text-sm w-40 p-0 h-auto focus-visible:ring-0 focus-visible:ring-offset-0"
            />
          </div>

          {/* Notification bell */}
          <button className="relative p-2 bg-muted rounded-md">
            <BellIcon className="h-5 w-5" />
            <span className="absolute top-0 right-0 w-2 h-2 bg-primary rounded-full"></span>
          </button>

          {/* User avatar */}
          <Avatar>
            <AvatarFallback className="p-0 overflow-hidden">
              <img src={knightLogo} alt="Knight Logo" className="w-full h-full object-cover" />
            </AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  );
};

export default Topbar;