import { Auth } from 'firebase/auth';
import { Firestore } from 'firebase/firestore';
import { FirebaseStorage } from 'firebase/storage';

declare const db: Firestore;
declare const auth: Auth;
declare const storage: FirebaseStorage;

export { db, auth, storage };
export default app;