import { useState } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Sidebar from "@/components/sidebar";
import Topbar from "@/components/topbar";
import Tasks from "@/pages/tasks";
import Habits from "@/pages/habits";
import Routine from "@/pages/routine";
import Progress from "@/pages/progress";
import Notifications from "@/pages/notifications";
import Videos from "@/pages/videos";
import VideoDetail from "@/pages/video-detail";
import TateShorts from "@/pages/tate-shorts";
import Challenges from "@/pages/challenges";
import Admin from "@/pages/admin";
import AuthPage from "@/pages/auth-page";
import { NotificationProvider } from "@/components/notification/notification-provider";
import { ToastContainer } from "react-toastify";
import SplashScreen from "@/components/splash-screen";
import FloatingWalletButton from "@/components/wallet/floating-wallet-button";
import { WebSocketProvider } from "@/components/websocket-provider";
import { AnnouncementBar } from "@/components/announcements";
import { useAuth } from "./hooks/use-auth";
import { AuthProvider } from "./components/auth/auth-provider";
import { ProtectedRoute } from "@/lib/protected-route";

function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen overflow-hidden text-white">
      <Sidebar />

      <div className="flex-1 flex flex-col overflow-hidden">
        <Topbar />
        <AnnouncementBar />

        <main className="flex-1 overflow-y-auto p-4 no-scrollbar">
          {children}
        </main>
      </div>
    </div>
  );
}

function ProtectedAppLayout({ children }: { children: React.ReactNode }) {
  return <AppLayout>{children}</AppLayout>;
}

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />

      <ProtectedRoute 
        path="/" 
        component={() => (
          <ProtectedAppLayout>
            <Dashboard />
          </ProtectedAppLayout>
        )} 
      />

      <ProtectedRoute 
        path="/tasks" 
        component={() => (
          <ProtectedAppLayout>
            <Tasks />
          </ProtectedAppLayout>
        )} 
      />

      <ProtectedRoute 
        path="/habits" 
        component={() => (
          <ProtectedAppLayout>
            <Habits />
          </ProtectedAppLayout>
        )} 
      />

      <ProtectedRoute 
        path="/routine" 
        component={() => (
          <ProtectedAppLayout>
            <Routine />
          </ProtectedAppLayout>
        )} 
      />

      <ProtectedRoute 
        path="/progress" 
        component={() => (
          <ProtectedAppLayout>
            <Progress />
          </ProtectedAppLayout>
        )} 
      />

      <ProtectedRoute 
        path="/notifications" 
        component={() => (
          <ProtectedAppLayout>
            <Notifications />
          </ProtectedAppLayout>
        )} 
      />

      <ProtectedRoute 
        path="/videos" 
        component={() => (
          <ProtectedAppLayout>
            <Videos />
          </ProtectedAppLayout>
        )} 
      />

      <ProtectedRoute 
        path="/videos/:id" 
        component={() => (
          <ProtectedAppLayout>
            <VideoDetail />
          </ProtectedAppLayout>
        )} 
      />

      <ProtectedRoute 
        path="/tate-shorts" 
        component={() => (
          <ProtectedAppLayout>
            <TateShorts />
          </ProtectedAppLayout>
        )} 
      />

      <ProtectedRoute 
        path="/challenges" 
        component={() => (
          <ProtectedAppLayout>
            <Challenges />
          </ProtectedAppLayout>
        )} 
      />

      <ProtectedRoute 
        path="/admin" 
        component={() => (
          <ProtectedAppLayout>
            <Admin />
          </ProtectedAppLayout>
        )} 
      />

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [loaded, setLoaded] = useState(false);

  if (!loaded) {
    return (
      <QueryClientProvider client={queryClient}>
        <SplashScreen onFinish={() => setLoaded(true)} />
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <WebSocketProvider>
          <NotificationProvider>
            <Router />
            <FloatingWalletButton />
            <Toaster />
            <ToastContainer 
              position="top-right"
              autoClose={5000}
              hideProgressBar={false}
              newestOnTop
              closeOnClick
              rtl={false}
              pauseOnFocusLoss
              draggable
              pauseOnHover
              theme="dark"
            />
          </NotificationProvider>
        </WebSocketProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;