import { Task, Habit, TaskPriority, TaskCategories, TaskPriorities, RoutineCategories } from '@shared/schema';

// Helper for formatting data
export interface StatsData {
  tasksCompleted: number;
  totalTasks: number;
  habitsTracked: number;
  totalHabits: number;
  currentStreak: number;
  levelProgress: number;
  level: number;
}

export interface ChartData {
  name: string;
  value: number;
}

// Calculate stats from tasks and habits
export function calculateStats(
  tasks: Task[], 
  habits: Habit[], 
  currentStreak: number = 0,
  level: number = 1,
  levelProgress: number = 0
): StatsData {
  const tasksCompleted = tasks.filter(task => task.completed).length;
  const totalTasks = tasks.length;
  const habitsTracked = habits.filter(habit => habit.streak > 0).length;
  const totalHabits = habits.length;

  return {
    tasksCompleted,
    totalTasks,
    habitsTracked,
    totalHabits,
    currentStreak,
    level,
    levelProgress
  };
}

// Generate data for category-based pie chart
export function generateCategoryChartData(tasks: Task[]): ChartData[] {
  const categoryCounts: Record<string, number> = {};
  
  tasks.forEach(task => {
    if (categoryCounts[task.category]) {
      categoryCounts[task.category]++;
    } else {
      categoryCounts[task.category] = 1;
    }
  });

  return Object.entries(categoryCounts).map(([name, value]) => ({
    name,
    value
  }));
}

// Generate data for priority-based bar chart
export function generatePriorityChartData(tasks: Task[]): ChartData[] {
  const priorityCounts: Record<string, number> = {
    [TaskPriorities.HIGH]: 0,
    [TaskPriorities.MEDIUM]: 0,
    [TaskPriorities.LOW]: 0
  };
  
  tasks.forEach(task => {
    priorityCounts[task.priority]++;
  });

  return Object.entries(priorityCounts).map(([name, value]) => ({
    name,
    value
  }));
}

// Generate data for completion status chart
export function generateCompletionChartData(tasks: Task[]): ChartData[] {
  const completed = tasks.filter(task => task.completed).length;
  const pending = tasks.length - completed;

  return [
    { name: 'Completed', value: completed },
    { name: 'Pending', value: pending }
  ];
}

// Generate streak data for habits over time (last 7 days)
export function generateStreakData(habits: Habit[]): ChartData[] {
  return habits.map(habit => ({
    name: habit.title,
    value: habit.streak
  })).sort((a, b) => b.value - a.value);
}

// Get appropriate icon colors based on priority
export function getPriorityColor(priority: TaskPriority | string): string {
  switch (priority.toLowerCase()) {
    case 'high':
      return 'text-destructive';
    case 'medium':
      return 'text-accent';
    case 'low':
      return 'text-chart-3';
    default:
      return 'text-muted-foreground';
  }
}

// Get motivation message based on completion ratio
export function getMotivationMessage(completedRatio: number): string {
  if (completedRatio >= 0.9) {
    return "Absolute legend! You're crushing it like a Top G!";
  } else if (completedRatio >= 0.7) {
    return "Impressive discipline! Keep dominating!";
  } else if (completedRatio >= 0.5) {
    return "Solid progress. Step it up to reach the next level!";
  } else if (completedRatio >= 0.3) {
    return "You're putting in work. Time to push harder!";
  } else {
    return "Wake up! The matrix has you. Break free and conquer your tasks!";
  }
}
