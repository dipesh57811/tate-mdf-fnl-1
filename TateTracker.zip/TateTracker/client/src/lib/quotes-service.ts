import tateQuotes from '@assets/tate_quotes.txt?raw';

// Define a class to manage quotes with memory of recently used quotes
export class QuotesService {
  private quotes: string[] = [];
  private recentlyUsedQuotes: string[] = [];
  private maxRecentQuotes: number = 10; // Don't repeat the last 10 quotes
  
  constructor() {
    this.loadQuotes();
  }
  
  private loadQuotes() {
    // Load quotes from the text file
    if (tateQuotes) {
      this.quotes = tateQuotes.split('\n').filter(quote => quote.trim() !== '');
      console.log(`Loaded ${this.quotes.length} Tate quotes`);
    } else {
      console.error('Failed to load quotes from file');
      // Fallback quotes in case the file fails to load
      this.quotes = [
        "Discipline is the key to success. Stay focused, G!",
        "Your mind must be stronger than your feelings. Stay focused, G!",
        "Chase excellence, and success will chase you. Stay focused, G!"
      ];
    }
  }
  
  public getRandomQuote(): string {
    if (this.quotes.length === 0) {
      return "Success isn't about avoiding failure; it's about persevering despite it. Stay focused, G!";
    }
    
    // Create a pool of quotes that excludes recently used ones
    const availableQuotes = this.quotes.filter(
      quote => !this.recentlyUsedQuotes.includes(quote)
    );
    
    // If we've exhausted all non-repeated quotes, use all quotes
    const quotesPool = availableQuotes.length > 0 ? availableQuotes : this.quotes;
    
    // Get a random quote from the pool
    const randomIndex = Math.floor(Math.random() * quotesPool.length);
    const selectedQuote = quotesPool[randomIndex];
    
    // Add to recently used quotes and manage the size of the recent quotes list
    this.addToRecentlyUsed(selectedQuote);
    
    return selectedQuote;
  }
  
  private addToRecentlyUsed(quote: string) {
    // Add the quote to recently used list
    this.recentlyUsedQuotes.push(quote);
    
    // If we exceed our max, remove the oldest one
    if (this.recentlyUsedQuotes.length > this.maxRecentQuotes) {
      this.recentlyUsedQuotes.shift();
    }
  }
}

// Create a singleton instance
export const quotesService = new QuotesService();

// Export a simple function to get a random quote
export function getRandomTateQuote(): string {
  return quotesService.getRandomQuote();
}