
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Menu, Home, CheckSquare, Award, Calendar, User } from "lucide-react";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("home");

  return (
    <div className="min-h-screen bg-[#0F0F0F] text-white font-sans">
      {/* Sidebar */}
      <div className="fixed top-0 left-0 h-full w-16 bg-[#1A1A1A] flex flex-col items-center py-4 space-y-6">
        <Menu className="w-6 h-6 text-gray-400" />
        <Home className={`w-6 h-6 ${activeTab === "home" ? "text-yellow-500" : "text-gray-400"}`} onClick={() => setActiveTab("home")} />
        <CheckSquare className={`w-6 h-6 ${activeTab === "tasks" ? "text-yellow-500" : "text-gray-400"}`} onClick={() => setActiveTab("tasks")} />
        <Award className={`w-6 h-6 ${activeTab === "awards" ? "text-yellow-500" : "text-gray-400"}`} onClick={() => setActiveTab("awards")} />
        <Calendar className={`w-6 h-6 ${activeTab === "calendar" ? "text-yellow-500" : "text-gray-400"}`} onClick={() => setActiveTab("calendar")} />
        <User className={`w-6 h-6 ${activeTab === "profile" ? "text-yellow-500" : "text-gray-400"}`} onClick={() => setActiveTab("profile")} />
      </div>

      {/* Main Content */}
      <div className="ml-20 px-6 py-8">
        <h1 className="text-3xl font-bold mb-6">Dashboard</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          <Card className="bg-[#1E1E1E] border-none">
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold">Welcome Back</h2>
              <p className="text-sm text-gray-400 mt-1">Username: TRW User</p>
              <p className="text-sm text-gray-400">Role: Gold King</p>
            </CardContent>
          </Card>

          <Card className="bg-[#1E1E1E] border-none">
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold">Lessons Completed</h2>
              <p className="text-2xl text-yellow-400 mt-2">50+</p>
            </CardContent>
          </Card>

          <Card className="bg-[#1E1E1E] border-none">
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold">Balance</h2>
              <p className="text-2xl text-green-400 mt-2">1,520 TRW Coins</p>
            </CardContent>
          </Card>
        </div>

        {/* Courses */}
        <div className="mt-10">
          <h2 className="text-2xl font-semibold mb-4">Your Courses</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {["Hero's Year", "Self Improvement", "The Council", "Champion's Hall"].map((course, index) => (
              <Card key={index} className="bg-[#1E1E1E] border border-gray-700 hover:border-yellow-500">
                <CardContent className="p-4">
                  <h3 className="text-lg font-medium">{course}</h3>
                  <p className="text-sm text-gray-500">50+ Lessons</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
