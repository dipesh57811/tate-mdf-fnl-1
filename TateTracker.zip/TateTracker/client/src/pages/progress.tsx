import { useQuery } from "@tanstack/react-query";
import { Task, Habit } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  calculateStats, 
  generateCategoryChartData, 
  generatePriorityChartData,
  generateCompletionChartData,
  generateStreakData,
  getMotivationMessage
} from "@/lib/data";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from "recharts";

const COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))'
];

const ProgressPage = () => {
  // Fetch tasks
  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ['/api/tasks']
  });
  
  // Fetch habits
  const { data: habits = [] } = useQuery<Habit[]>({
    queryKey: ['/api/habits']
  });
  
  // Fetch user for streak and level
  const { data: user } = useQuery({
    queryKey: ['/api/user']
  });
  
  // Calculate stats
  const stats = calculateStats(
    tasks,
    habits,
    user?.currentStreak || 0,
    user?.level || 1,
    user?.levelProgress || 0
  );
  
  // Generate chart data
  const categoryChartData = generateCategoryChartData(tasks);
  const priorityChartData = generatePriorityChartData(tasks);
  const completionChartData = generateCompletionChartData(tasks);
  const streakData = generateStreakData(habits);
  
  // Calculate completion ratio for motivation message
  const completionRatio = stats.totalTasks > 0 
    ? stats.tasksCompleted / stats.totalTasks 
    : 0;
  
  const motivationalMessage = getMotivationMessage(completionRatio);

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-montserrat font-bold">Progress</h2>
          <p className="text-muted-foreground">Track your growth and accomplishments</p>
        </div>
      </div>
      
      {/* Progress Overview Card */}
      <Card className="bg-gradient-to-r from-primary/20 to-accent/20 border border-accent/30 mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center mb-4">
            <div>
              <h3 className="text-xl font-bold">TOP G PROGRESS</h3>
              <p className="text-muted-foreground">{motivationalMessage}</p>
            </div>
            <div className="flex items-center mt-4 md:mt-0">
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Current Level</p>
                <p className="text-3xl font-['Bebas_Neue']">LEVEL {stats.level}</p>
              </div>
              <div className="w-16 h-16 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center ml-4 text-2xl font-bold text-white">
                {stats.level}
              </div>
            </div>
          </div>
          
          <div className="mt-4">
            <div className="flex justify-between mb-2">
              <p className="text-sm">Level Progress</p>
              <p className="text-sm">{stats.levelProgress}%</p>
            </div>
            <Progress 
              value={stats.levelProgress} 
              className="h-2 bg-secondary"
              indicatorClassName="bg-gradient-to-r from-primary to-accent"
            />
          </div>
        </CardContent>
      </Card>
      
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card className="bg-secondary">
          <CardContent className="p-4">
            <div className="flex flex-col">
              <p className="text-sm text-muted-foreground">Tasks Completed</p>
              <div className="flex items-baseline mt-1">
                <p className="text-3xl font-bold">{stats.tasksCompleted}</p>
                <p className="text-sm text-muted-foreground ml-1">/ {stats.totalTasks}</p>
              </div>
              <Progress 
                value={stats.totalTasks > 0 ? (stats.tasksCompleted / stats.totalTasks) * 100 : 0} 
                className="h-1 bg-muted mt-2"
                indicatorClassName="bg-primary"
              />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-secondary">
          <CardContent className="p-4">
            <div className="flex flex-col">
              <p className="text-sm text-muted-foreground">Active Habits</p>
              <div className="flex items-baseline mt-1">
                <p className="text-3xl font-bold">{stats.habitsTracked}</p>
                <p className="text-sm text-muted-foreground ml-1">/ {stats.totalHabits}</p>
              </div>
              <Progress 
                value={stats.totalHabits > 0 ? (stats.habitsTracked / stats.totalHabits) * 100 : 0} 
                className="h-1 bg-muted mt-2"
                indicatorClassName="bg-accent"
              />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-secondary">
          <CardContent className="p-4">
            <div className="flex flex-col">
              <p className="text-sm text-muted-foreground">Current Streak</p>
              <p className="text-3xl font-bold mt-1">{stats.currentStreak} <span className="text-sm text-accent font-normal">days</span></p>
              <div className="flex items-center space-x-1 mt-2">
                {Array.from({ length: 7 }).map((_, i) => (
                  <div 
                    key={i} 
                    className={`h-1 flex-1 rounded-full ${i < (stats.currentStreak % 7) ? 'bg-primary' : 'bg-muted'}`} 
                  ></div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-secondary">
          <CardContent className="p-4">
            <div className="flex flex-col">
              <p className="text-sm text-muted-foreground">Consistency Score</p>
              <p className="text-3xl font-bold mt-1">
                {Math.floor((completionRatio + (stats.habitsTracked / Math.max(stats.totalHabits, 1))) * 50)}
                <span className="text-sm text-muted-foreground font-normal">/100</span>
              </p>
              <Progress 
                value={(completionRatio + (stats.habitsTracked / Math.max(stats.totalHabits, 1))) * 50} 
                className="h-1 bg-muted mt-2"
                indicatorClassName="bg-gradient-to-r from-primary to-accent"
              />
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Charts */}
      <Tabs defaultValue="tasks" className="mb-6">
        <TabsList>
          <TabsTrigger value="tasks">Task Analysis</TabsTrigger>
          <TabsTrigger value="habits">Habit Streaks</TabsTrigger>
        </TabsList>
        
        <TabsContent value="tasks" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Tasks by Category Chart */}
            <Card className="bg-secondary">
              <CardHeader>
                <CardTitle className="text-lg">Tasks by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  {categoryChartData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={categoryChartData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        >
                          {categoryChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="flex h-full items-center justify-center text-muted-foreground">
                      No task data available
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
            
            {/* Tasks by Priority Chart */}
            <Card className="bg-secondary">
              <CardHeader>
                <CardTitle className="text-lg">Tasks by Priority</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  {priorityChartData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={priorityChartData}>
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="value" fill="hsl(var(--primary))">
                          {priorityChartData.map((entry, index) => {
                            let fill = 'hsl(var(--chart-3))'; // Low
                            if (entry.name === 'High') {
                              fill = 'hsl(var(--destructive))';
                            } else if (entry.name === 'Medium') {
                              fill = 'hsl(var(--accent))';
                            }
                            return <Cell key={`cell-${index}`} fill={fill} />;
                          })}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="flex h-full items-center justify-center text-muted-foreground">
                      No task data available
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
            
            {/* Completion Status Chart */}
            <Card className="bg-secondary md:col-span-2">
              <CardHeader>
                <CardTitle className="text-lg">Completion Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  {completionChartData.length > 0 && tasks.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={completionChartData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={100}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        >
                          <Cell fill="hsl(var(--primary))" />
                          <Cell fill="hsl(var(--muted-foreground))" />
                        </Pie>
                        <Tooltip />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="flex h-full items-center justify-center text-muted-foreground">
                      No task data available
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="habits" className="mt-4">
          <Card className="bg-secondary">
            <CardHeader>
              <CardTitle className="text-lg">Habit Streaks</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                {streakData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={streakData}
                      layout="vertical"
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <XAxis type="number" />
                      <YAxis type="category" dataKey="name" width={150} />
                      <Tooltip formatter={(value) => [`${value} days`, 'Streak']} />
                      <Bar dataKey="value" fill="url(#streakGradient)">
                        {streakData.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={entry.value > 10 ? 'hsl(var(--accent))' : 'hsl(var(--primary))'}
                          />
                        ))}
                      </Bar>
                      <defs>
                        <linearGradient id="streakGradient" x1="0" y1="0" x2="1" y2="0">
                          <stop offset="0%" stopColor="hsl(var(--primary))" />
                          <stop offset="100%" stopColor="hsl(var(--accent))" />
                        </linearGradient>
                      </defs>
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex h-full items-center justify-center text-muted-foreground">
                    No habit data available
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          
          {/* Motivation Card */}
          <Card className="bg-gradient-to-r from-primary/20 to-accent/20 border border-accent/30 mt-6">
            <CardContent className="p-6">
              <p className="text-2xl font-['Bebas_Neue'] tracking-wide leading-snug uppercase">
                "SUCCESS IS NOT OWNED, IT'S RENTED. AND THE RENT IS DUE EVERY DAY."
              </p>
              <p className="text-accent italic mt-2">- Andrew Tate</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProgressPage;
