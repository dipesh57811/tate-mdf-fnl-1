import { useEffect, useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Challenge, UserChallenge } from '@shared/schema';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Trophy, Calendar, Clock, BarChart, Users, ArrowRight, CheckCircle, Flame, TrendingUp, X } from 'lucide-react';
import { formatDistance } from 'date-fns';

export default function ChallengesPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>('active');
  
  const { data: challenges = [] } = useQuery({
    queryKey: ['/api/challenges/active'],
    queryFn: async () => {
      const res = await fetch('/api/challenges/active');
      if (!res.ok) throw new Error('Failed to fetch challenges');
      return res.json();
    },
    enabled: activeTab === 'active'
  });

  const { data: myChallenges = [] } = useQuery({
    queryKey: [`/api/user/${user?.id}/challenges`],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const res = await fetch(`/api/user/${user.id}/challenges`);
      if (!res.ok) throw new Error('Failed to fetch user challenges');
      
      const userChallenges = await res.json();
      
      // Map challenges to their details
      const challengeDetails = await Promise.all(
        userChallenges.map(async (uc: UserChallenge) => {
          const challengeRes = await fetch(`/api/challenges/${uc.challengeId}`);
          if (!challengeRes.ok) return null;
          const challenge = await challengeRes.json();
          return {
            ...uc,
            challenge
          };
        })
      );
      
      return challengeDetails.filter(Boolean);
    },
    enabled: activeTab === 'my-challenges' && !!user?.id
  });

  const joinMutation = useMutation({
    mutationFn: async (challengeId: number) => {
      if (!user?.id) throw new Error('You must be logged in to join a challenge');
      
      const res = await apiRequest(
        'POST', 
        `/api/user/${user.id}/challenges/${challengeId}/join`
      );
      
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Challenge Joined',
        description: 'You have successfully joined the challenge!',
      });
      
      // Refetch both queries
      queryClient.invalidateQueries({ queryKey: [`/api/user/${user?.id}/challenges`] });
      queryClient.invalidateQueries({ queryKey: ['/api/challenges/active'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to join challenge',
        description: error.message,
        variant: 'destructive',
      });
    }
  });

  const updateProgressMutation = useMutation({
    mutationFn: async ({ userChallengeId, progress }: { userChallengeId: number, progress: number }) => {
      if (!user?.id) throw new Error('You must be logged in to update progress');
      
      const res = await apiRequest(
        'PATCH', 
        `/api/user/${user.id}/challenges/${userChallengeId}/progress`,
        { progress }
      );
      
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Progress Updated',
        description: 'Your challenge progress has been updated.',
      });
      
      // Refetch user challenges
      queryClient.invalidateQueries({ queryKey: [`/api/user/${user?.id}/challenges`] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to update progress',
        description: error.message,
        variant: 'destructive',
      });
    }
  });

  const completeChallengeMutation = useMutation({
    mutationFn: async (userChallengeId: number) => {
      if (!user?.id) throw new Error('You must be logged in to complete a challenge');
      
      const res = await apiRequest(
        'POST', 
        `/api/user/${user.id}/challenges/${userChallengeId}/complete`
      );
      
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Challenge Completed',
        description: 'Congratulations! You have completed the challenge.',
      });
      
      // Refetch user challenges
      queryClient.invalidateQueries({ queryKey: [`/api/user/${user?.id}/challenges`] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to complete challenge',
        description: error.message,
        variant: 'destructive',
      });
    }
  });

  // Handle joining a challenge
  const handleJoinChallenge = (challengeId: number) => {
    joinMutation.mutate(challengeId);
  };

  // Handle updating progress
  const handleUpdateProgress = (userChallengeId: number, currentProgress: number) => {
    updateProgressMutation.mutate({ 
      userChallengeId, 
      progress: currentProgress + 1 
    });
  };

  // Handle completing a challenge
  const handleCompleteChallenge = (userChallengeId: number) => {
    completeChallengeMutation.mutate(userChallengeId);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'daily':
        return <Calendar className="h-4 w-4" />;
      case 'weekly':
        return <TrendingUp className="h-4 w-4" />;
      case 'special':
        return <Trophy className="h-4 w-4" />;
      case 'community':
        return <Users className="h-4 w-4" />;
      default:
        return <Calendar className="h-4 w-4" />;
    }
  };

  // Check if user has already joined a challenge
  const hasJoinedChallenge = (challengeId: number) => {
    return myChallenges.some((uc: any) => uc.challengeId === challengeId);
  };

  // Find a user challenge by challenge ID
  const findUserChallenge = (challengeId: number) => {
    return myChallenges.find((uc: any) => uc.challengeId === challengeId);
  };

  const renderActiveChallenges = () => {
    if (challenges.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center py-12">
          <X className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold">No Active Challenges</h3>
          <p className="text-muted-foreground">There are no active challenges at the moment. Check back later!</p>
        </div>
      );
    }

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {challenges.map((challenge: Challenge) => {
          const joined = hasJoinedChallenge(challenge.id);
          const userChallenge = findUserChallenge(challenge.id);
          
          return (
            <Card key={challenge.id} className="overflow-hidden border-2 hover:border-primary/50 transition-all duration-300">
              <CardHeader className="bg-muted/30 relative pb-2">
                <div className="flex justify-between items-start">
                  <Badge variant="outline" className="flex items-center gap-1">
                    {getCategoryIcon(challenge.category)}
                    {challenge.category.charAt(0).toUpperCase() + challenge.category.slice(1)}
                  </Badge>
                  <Badge variant={joined ? "secondary" : "outline"}>
                    {joined ? "Joined" : `Level ${challenge.requiredLevel}+`}
                  </Badge>
                </div>
                <CardTitle className="text-xl mt-2">{challenge.title}</CardTitle>
                <CardDescription className="text-foreground/80">
                  {challenge.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="flex flex-col gap-3">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-1">
                      <Trophy className="h-4 w-4 text-yellow-500" />
                      <span>{challenge.xpReward} XP</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Flame className="h-4 w-4 text-amber-500" />
                      <span>{challenge.coinReward} Coins</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <BarChart className="h-4 w-4 text-blue-500" />
                      <span>Target: {challenge.target}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>
                        {formatDistance(new Date(challenge.endDate), new Date(), { addSuffix: true })}
                      </span>
                    </div>
                    <div>
                      <span>{challenge.completedCount || 0} completions</span>
                    </div>
                  </div>
                  
                  {joined && userChallenge && (
                    <div className="mt-2">
                      <div className="flex justify-between mb-1 text-sm">
                        <span>Progress: {userChallenge.progress} / {challenge.target}</span>
                        <span>{Math.round((userChallenge.progress / challenge.target) * 100)}%</span>
                      </div>
                      <Progress value={(userChallenge.progress / challenge.target) * 100} className="h-2" />
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="pt-0">
                {!joined ? (
                  <Button 
                    className="w-full" 
                    onClick={() => handleJoinChallenge(challenge.id)}
                    disabled={joinMutation.isPending || user?.level < challenge.requiredLevel}
                  >
                    {user?.level < challenge.requiredLevel 
                      ? `Requires Level ${challenge.requiredLevel}` 
                      : "Join Challenge"}
                  </Button>
                ) : userChallenge && !userChallenge.isCompleted ? (
                  <div className="flex w-full gap-2">
                    <Button 
                      variant="outline" 
                      className="flex-1" 
                      onClick={() => handleUpdateProgress(userChallenge.id, userChallenge.progress)}
                      disabled={updateProgressMutation.isPending}
                    >
                      +1 Progress
                    </Button>
                    <Button
                      className="flex-1"
                      onClick={() => handleCompleteChallenge(userChallenge.id)}
                      disabled={completeChallengeMutation.isPending}
                    >
                      Complete
                    </Button>
                  </div>
                ) : (
                  <Button variant="secondary" className="w-full" disabled>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Completed
                  </Button>
                )}
              </CardFooter>
            </Card>
          );
        })}
      </div>
    );
  };

  const renderMyChallenges = () => {
    if (myChallenges.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center py-12">
          <X className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold">No Challenges Joined</h3>
          <p className="text-muted-foreground">You haven't joined any challenges yet. Check the active challenges!</p>
          <Button 
            variant="outline" 
            className="mt-4" 
            onClick={() => setActiveTab('active')}
          >
            Browse Challenges
            <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        </div>
      );
    }

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {myChallenges.map((userChallenge: any) => {
          const challenge = userChallenge.challenge;
          if (!challenge) return null;
          
          return (
            <Card key={userChallenge.id} className={`overflow-hidden border-2 transition-all duration-300 ${userChallenge.isCompleted ? 'border-green-600/50' : 'hover:border-primary/50'}`}>
              <CardHeader className={`relative pb-2 ${userChallenge.isCompleted ? 'bg-green-600/10' : 'bg-muted/30'}`}>
                <div className="flex justify-between items-start">
                  <Badge variant="outline" className="flex items-center gap-1">
                    {getCategoryIcon(challenge.category)}
                    {challenge.category.charAt(0).toUpperCase() + challenge.category.slice(1)}
                  </Badge>
                  <Badge variant={userChallenge.isCompleted ? "outline" : "secondary"} className={userChallenge.isCompleted ? "border-green-600 text-green-600" : ""}>
                    {userChallenge.isCompleted ? "Completed" : "In Progress"}
                  </Badge>
                </div>
                <CardTitle className="text-xl mt-2">{challenge.title}</CardTitle>
                <CardDescription className="text-foreground/80">
                  {challenge.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="flex flex-col gap-3">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-1">
                      <Trophy className="h-4 w-4 text-yellow-500" />
                      <span>{challenge.xpReward} XP</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Flame className="h-4 w-4 text-amber-500" />
                      <span>{challenge.coinReward} Coins</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>
                        {formatDistance(new Date(challenge.endDate), new Date(), { addSuffix: true })}
                      </span>
                    </div>
                    <div>
                      <span>Joined {formatDistance(new Date(userChallenge.joinedAt), new Date(), { addSuffix: true })}</span>
                    </div>
                  </div>
                  
                  <div className="mt-2">
                    <div className="flex justify-between mb-1 text-sm">
                      <span>Progress: {userChallenge.progress} / {challenge.target}</span>
                      <span>{Math.round((userChallenge.progress / challenge.target) * 100)}%</span>
                    </div>
                    <Progress value={(userChallenge.progress / challenge.target) * 100} className="h-2" />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="pt-0">
                {!userChallenge.isCompleted ? (
                  <div className="flex w-full gap-2">
                    <Button 
                      variant="outline" 
                      className="flex-1" 
                      onClick={() => handleUpdateProgress(userChallenge.id, userChallenge.progress)}
                      disabled={updateProgressMutation.isPending}
                    >
                      +1 Progress
                    </Button>
                    <Button
                      className="flex-1"
                      onClick={() => handleCompleteChallenge(userChallenge.id)}
                      disabled={completeChallengeMutation.isPending}
                    >
                      Complete
                    </Button>
                  </div>
                ) : (
                  <div className="text-center w-full text-sm text-muted-foreground">
                    {userChallenge.completedAt ? (
                      <>Completed {formatDistance(new Date(userChallenge.completedAt), new Date(), { addSuffix: true })}</>
                    ) : (
                      <>Challenge completed</>
                    )}
                  </div>
                )}
              </CardFooter>
            </Card>
          );
        })}
      </div>
    );
  };

  return (
    <div className="container mx-auto py-6 max-w-7xl">
      <div className="flex flex-col items-start gap-6">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold tracking-tight">Challenges</h1>
          <p className="text-muted-foreground">
            Complete challenges to earn XP, coins, and prove your dedication to the Top G mindset.
          </p>
        </div>

        <Tabs 
          defaultValue="active" 
          value={activeTab} 
          onValueChange={setActiveTab}
          className="w-full"
        >
          <TabsList className="grid w-full grid-cols-2 max-w-md">
            <TabsTrigger value="active">Active Challenges</TabsTrigger>
            <TabsTrigger value="my-challenges">My Challenges</TabsTrigger>
          </TabsList>
          <div className="mt-6">
            <TabsContent value="active" className="mt-0">
              {renderActiveChallenges()}
            </TabsContent>
            <TabsContent value="my-challenges" className="mt-0">
              {renderMyChallenges()}
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
}