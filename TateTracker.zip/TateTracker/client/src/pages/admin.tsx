import React from 'react';
import { AnnouncementAdmin } from '@/components/announcements';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BellRing, Cpu, Users } from 'lucide-react';
import AdminGuard from '@/components/auth/admin-guard';

const AdminPage: React.FC = () => {
  return (
    <AdminGuard>
      <div>
        <div className="mb-8">
          <h2 className="text-3xl font-bebas-neue text-red-500">ADMIN CONTROLS</h2>
          <p className="text-muted-foreground">Manage your application</p>
        </div>

        <Tabs defaultValue="announcements" className="mb-8">
          <TabsList className="grid grid-cols-3 mb-6">
            <TabsTrigger value="announcements" className="data-[state=active]:bg-red-800">
              <BellRing className="h-4 w-4 mr-2" />
              Announcements
            </TabsTrigger>
            <TabsTrigger value="users" className="data-[state=active]:bg-red-800">
              <Users className="h-4 w-4 mr-2" />
              Users
            </TabsTrigger>
            <TabsTrigger value="system" className="data-[state=active]:bg-red-800">
              <Cpu className="h-4 w-4 mr-2" />
              System
            </TabsTrigger>
          </TabsList>

          <TabsContent value="announcements">
            <AnnouncementAdmin />
          </TabsContent>

          <TabsContent value="users">
            <Card className="bg-gray-900">
              <CardHeader>
                <CardTitle>User Management</CardTitle>
                <CardDescription>Manage users (Coming soon)</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">
                  This feature will be available in a future update. For now, please use the default user account.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="system">
            <Card className="bg-gray-900">
              <CardHeader>
                <CardTitle>System Settings</CardTitle>
                <CardDescription>Configure system settings (Coming soon)</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">
                  This feature will be available in a future update.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AdminGuard>
  );
};

export default AdminPage;