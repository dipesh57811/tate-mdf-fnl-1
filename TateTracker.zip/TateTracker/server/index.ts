import express, { type Request, Response, NextFunction, Router } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { storage } from "./storage";

const router = Router();

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let logLine = `${req.method} ${path}`;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      // Only log response if it's not too large
      const responseStr = JSON.stringify(capturedJsonResponse);
      if (responseStr.length < 100) {
        logLine += ` :: ${responseStr}`;
      }
      log(logLine);
    }
  });

  next();
});

(async () => {
  // Seed initial data - this will only add data if the database is empty
  try {
    await (storage as any).seedInitialData();
  } catch (error) {
    console.error("Error seeding initial data:", error);
  }

  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
  });

  // Setup Vite middleware first before other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = process.env.PORT || 5000;
  server.listen(port, "0.0.0.0", () => {
    log(`Server is running on http://0.0.0.0:${port}`);
    log(
      `View your Repl at: https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`,
    );
  });
})();