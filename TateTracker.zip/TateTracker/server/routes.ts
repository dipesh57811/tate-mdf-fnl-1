import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  insertTaskSchema, 
  insertHabitSchema, 
  insertHabitCompletionSchema,
  insertRoutineItemSchema,
  insertVideoSchema,
  insertVideoCommentSchema,
  insertAnnouncementSchema,
  insertChallengeSchema,
  insertUserChallengeSchema,
  VideoCategories,
  AnnouncementTypes,
  ChallengeCategories
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);
  // Premium Routines routes
  app.get("/api/premium-routines", async (req, res) => {
    try {
      const routines = await storage.getPremiumRoutines();
      res.json(routines);
    } catch (error) {
      res.status(500).json({ error: "Failed to get premium routines" });
    }
  });

  app.get("/api/premium-routines/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const routine = await storage.getPremiumRoutineById(id);
      if (!routine) {
        return res.status(404).json({ error: "Premium routine not found" });
      }
      res.json(routine);
    } catch (error) {
      res.status(500).json({ error: "Failed to get premium routine" });
    }
  });

  app.get("/api/user/:userId/premium-routines", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const routines = await storage.getUserPremiumRoutines(userId);
      res.json(routines);
    } catch (error) {
      res.status(500).json({ error: "Failed to get user premium routines" });
    }
  });

  app.post("/api/premium-routines/:id/unlock", async (req, res) => {
    try {
      const routineId = parseInt(req.params.id);
      const { userId } = req.body;

      if (!userId) {
        return res.status(400).json({ error: "User ID is required" });
      }

      await storage.unlockPremiumRoutine(userId, routineId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // User Coins routes
  app.patch("/api/user/:id/coins", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { coins } = req.body;

      if (typeof coins !== 'number') {
        return res.status(400).json({ error: "Coins must be a number" });
      }

      const user = await storage.updateUserCoins(id, coins);
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to update user coins" });
    }
  });

  app.post("/api/user/:id/earn-coins", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { amount = 10 } = req.body;
      
      // Get current user
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Update coins
      const updatedUser = await storage.updateUserCoins(id, user.coins + amount);
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ error: "Failed to earn coins" });
    }
  });
  // API routes
  const apiRouter = app.route("/api");

  // This route is now handled by auth.ts
  // Keep this here for backward compatibility with existing code
  app.get("/api/user", async (req, res) => {
    if (req.isAuthenticated()) {
      // Don't send password
      const { password, ...userWithoutPassword } = req.user as any;
      return res.json(userWithoutPassword);
    }
    
    try {
      // Fallback to default user with ID 1 if not authenticated
      const user = await storage.getUser(1);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      // Don't send password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Error fetching user" });
    }
  });

  // Tasks endpoints
  app.get("/api/tasks", async (req, res) => {
    try {
      const tasks = await storage.getTasks(1);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Error fetching tasks" });
    }
  });

  app.get("/api/tasks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const task = await storage.getTaskById(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: "Error fetching task" });
    }
  });

  app.post("/api/tasks", async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask({
        ...taskData,
        userId: 1 // Default user
      });
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating task" });
    }
  });

  app.patch("/api/tasks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const task = await storage.getTaskById(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      const taskUpdate = insertTaskSchema.partial().parse(req.body);
      const updatedTask = await storage.updateTask(id, taskUpdate);
      res.json(updatedTask);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating task" });
    }
  });

  app.patch("/api/tasks/:id/complete", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const task = await storage.getTaskById(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      const { completed } = z.object({ completed: z.boolean() }).parse(req.body);
      const updatedTask = await storage.completeTask(id, completed);
      res.json(updatedTask);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating task completion status" });
    }
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const task = await storage.getTaskById(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      await storage.deleteTask(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting task" });
    }
  });

  // Habits endpoints
  app.get("/api/habits", async (req, res) => {
    try {
      const habits = await storage.getHabits(1);
      res.json(habits);
    } catch (error) {
      res.status(500).json({ message: "Error fetching habits" });
    }
  });

  app.get("/api/habits/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const habit = await storage.getHabitById(id);
      if (!habit) {
        return res.status(404).json({ message: "Habit not found" });
      }
      res.json(habit);
    } catch (error) {
      res.status(500).json({ message: "Error fetching habit" });
    }
  });

  app.post("/api/habits", async (req, res) => {
    try {
      const habitData = insertHabitSchema.parse(req.body);
      const habit = await storage.createHabit({
        ...habitData,
        userId: 1 // Default user
      });
      res.status(201).json(habit);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid habit data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating habit" });
    }
  });

  app.patch("/api/habits/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const habit = await storage.getHabitById(id);
      if (!habit) {
        return res.status(404).json({ message: "Habit not found" });
      }
      
      const habitUpdate = insertHabitSchema.partial().parse(req.body);
      const updatedHabit = await storage.updateHabit(id, habitUpdate);
      res.json(updatedHabit);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid habit data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating habit" });
    }
  });

  app.delete("/api/habits/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const habit = await storage.getHabitById(id);
      if (!habit) {
        return res.status(404).json({ message: "Habit not found" });
      }
      
      await storage.deleteHabit(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting habit" });
    }
  });

  // Habit completions endpoints
  app.get("/api/habits/:habitId/completions", async (req, res) => {
    try {
      const habitId = parseInt(req.params.habitId);
      const habit = await storage.getHabitById(habitId);
      if (!habit) {
        return res.status(404).json({ message: "Habit not found" });
      }
      
      const completions = await storage.getHabitCompletions(habitId);
      res.json(completions);
    } catch (error) {
      res.status(500).json({ message: "Error fetching habit completions" });
    }
  });

  app.post("/api/habits/:habitId/completions", async (req, res) => {
    try {
      const habitId = parseInt(req.params.habitId);
      const habit = await storage.getHabitById(habitId);
      if (!habit) {
        return res.status(404).json({ message: "Habit not found" });
      }
      
      // Check if already completed for today
      const today = new Date();
      const todayCompletions = await storage.getHabitCompletionsForDate(habitId, today);
      
      if (todayCompletions.length > 0) {
        return res.status(400).json({ message: "Habit already completed for today" });
      }
      
      const completion = await storage.createHabitCompletion({
        habitId,
        completedDate: today
      });
      
      // Update streak
      const allCompletions = await storage.getHabitCompletions(habitId);
      
      // Simple streak calculation
      const newStreak = habit.streak + 1;
      const updatedHabit = await storage.updateHabitStreak(habitId, newStreak);
      
      res.status(201).json({ completion, habit: updatedHabit });
    } catch (error) {
      res.status(500).json({ message: "Error completing habit" });
    }
  });

  // Routine endpoints
  app.get("/api/routine", async (req, res) => {
    try {
      const items = await storage.getRoutineItems(1);
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Error fetching routine items" });
    }
  });

  app.get("/api/routine/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getRoutineItemById(id);
      if (!item) {
        return res.status(404).json({ message: "Routine item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(500).json({ message: "Error fetching routine item" });
    }
  });

  app.post("/api/routine", async (req, res) => {
    try {
      const itemData = insertRoutineItemSchema.parse(req.body);
      const item = await storage.createRoutineItem({
        ...itemData,
        userId: 1 // Default user
      });
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid routine item data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating routine item" });
    }
  });

  app.patch("/api/routine/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getRoutineItemById(id);
      if (!item) {
        return res.status(404).json({ message: "Routine item not found" });
      }
      
      const itemUpdate = insertRoutineItemSchema.partial().parse(req.body);
      const updatedItem = await storage.updateRoutineItem(id, itemUpdate);
      res.json(updatedItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid routine item data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating routine item" });
    }
  });

  app.delete("/api/routine/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getRoutineItemById(id);
      if (!item) {
        return res.status(404).json({ message: "Routine item not found" });
      }
      
      await storage.deleteRoutineItem(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting routine item" });
    }
  });

  // Quotes endpoints
  app.get("/api/quotes", async (req, res) => {
    try {
      const quotes = await storage.getQuotes();
      res.json(quotes);
    } catch (error) {
      res.status(500).json({ message: "Error fetching quotes" });
    }
  });

  app.get("/api/quotes/random", async (req, res) => {
    try {
      const quote = await storage.getRandomQuote();
      if (!quote) {
        return res.status(404).json({ message: "No quotes available" });
      }
      res.json(quote);
    } catch (error) {
      res.status(500).json({ message: "Error fetching random quote" });
    }
  });

  // Video endpoints
  app.get("/api/videos", async (req, res) => {
    try {
      const { category } = req.query;
      let videos;
      
      if (category) {
        videos = await storage.getVideos(category as string);
      } else {
        videos = await storage.getVideos();
      }
      
      res.json(videos);
    } catch (error) {
      res.status(500).json({ message: "Error fetching videos" });
    }
  });

  app.get("/api/videos/categories", async (req, res) => {
    try {
      // Return all video categories
      const categories = Object.values(VideoCategories);
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Error fetching video categories" });
    }
  });

  app.get("/api/videos/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const video = await storage.getVideoById(id);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }

      // Increment views
      await storage.updateVideoViews(id, video.views + 1);
      
      // Re-fetch the video with updated view count
      const updatedVideo = await storage.getVideoById(id);
      res.json(updatedVideo);
    } catch (error) {
      res.status(500).json({ message: "Error fetching video" });
    }
  });

  app.post("/api/videos", async (req, res) => {
    try {
      const videoData = insertVideoSchema.parse(req.body);
      const video = await storage.createVideo({
        ...videoData,
        userId: 1 // Default user
      });
      
      // Broadcast notification for new video
      broadcastNotification({
        type: 'new_video',
        videoId: video.id,
        title: video.title,
        category: video.category,
        timestamp: new Date()
      });
      
      res.status(201).json(video);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid video data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating video" });
    }
  });

  app.patch("/api/videos/:id/like", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const video = await storage.getVideoById(id);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      
      // Increment likes
      const updatedVideo = await storage.updateVideoLikes(id, video.likes + 1);
      
      // Broadcast notification for video like
      broadcastNotification({
        type: 'video_liked',
        videoId: id,
        title: video.title,
        likes: updatedVideo?.likes || video.likes + 1,
        timestamp: new Date()
      });
      
      res.json(updatedVideo);
    } catch (error) {
      res.status(500).json({ message: "Error liking video" });
    }
  });

  app.delete("/api/videos/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const video = await storage.getVideoById(id);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      
      await storage.deleteVideo(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting video" });
    }
  });

  // Video comments endpoints
  app.get("/api/videos/:videoId/comments", async (req, res) => {
    try {
      const videoId = parseInt(req.params.videoId);
      const video = await storage.getVideoById(videoId);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      
      const comments = await storage.getVideoComments(videoId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Error fetching video comments" });
    }
  });

  app.post("/api/videos/:videoId/comments", async (req, res) => {
    try {
      const videoId = parseInt(req.params.videoId);
      const video = await storage.getVideoById(videoId);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      
      const commentData = insertVideoCommentSchema.parse(req.body);
      const comment = await storage.createVideoComment({
        ...commentData,
        videoId,
        userId: 1 // Default user
      });
      
      // Broadcast notification for new comment
      broadcastNotification({
        type: 'video_comment',
        videoId,
        videoTitle: video.title,
        commentId: comment.id,
        comment: comment.content.substring(0, 30) + (comment.content.length > 30 ? '...' : ''),
        timestamp: new Date()
      });
      
      res.status(201).json(comment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid comment data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating comment" });
    }
  });

  app.delete("/api/videos/comments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      // No need to check if comment exists, just try to delete it
      await storage.deleteVideoComment(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting comment" });
    }
  });

  // Endpoint to earn coins from watching videos
  app.post("/api/videos/:id/earn", async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const { userId } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const video = await storage.getVideoById(videoId);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      
      // Get current user
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Award coins based on video category and length
      let coinsEarned = 5; // Base amount
      
      // Optionally adjust based on category
      if (video.category === VideoCategories.TATE_LONG || 
          video.category === VideoCategories.TATE_PODCAST) {
        coinsEarned = 10; // More coins for longer content
      }
      
      // Update user coins
      const updatedUser = await storage.updateUserCoins(userId, user.coins + coinsEarned);
      
      // Broadcast notification for coins earned
      broadcastNotification({
        type: 'coins_earned',
        userId,
        videoId,
        videoTitle: video.title,
        coinsEarned,
        totalCoins: updatedUser.coins,
        timestamp: new Date()
      });
      
      res.json({ 
        success: true, 
        coinsEarned,
        totalCoins: updatedUser.coins
      });
    } catch (error) {
      res.status(500).json({ message: "Error earning coins from video" });
    }
  });

  const httpServer = createServer(app);
  
  // Set up WebSocket server for real-time notifications
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Store connected clients
  const clients = new Set<WebSocket>();
  
  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');
    clients.add(ws);
    
    // Send welcome message
    ws.send(JSON.stringify({
      type: 'welcome',
      message: 'Connected to TateMotivator WebSocket Server'
    }));
    
    // Handle messages from clients
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        console.log('Received message:', data);
        
        // Handle different message types
        switch (data.type) {
          case 'ping':
            ws.send(JSON.stringify({ type: 'pong', time: new Date() }));
            break;
          default:
            console.log('Unknown message type:', data.type);
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });
    
    // Handle client disconnection
    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
      clients.delete(ws);
    });
  });
  
  // Helper function to broadcast messages to all connected clients
  const broadcastNotification = (notification: any) => {
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(notification));
      }
    });
  };
  
  // Use this function to broadcast video notifications
  // Attach it to the video creation handler
  app.post('/api/videos/:id/notify', (req, res) => {
    const { id } = req.params;
    const { title, category } = req.body;
    
    broadcastNotification({
      type: 'new_video',
      videoId: parseInt(id),
      title,
      category,
      timestamp: new Date()
    });
    
    res.json({ success: true });
  });
  
  // Announcement endpoints
  app.post("/api/admin/announcements", async (req, res) => {
    try {
      // Check if user is admin (ID 1)
      if (!req.isAuthenticated() || (req.user as any).id !== 1) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const announcementData = insertAnnouncementSchema.parse(req.body);
      const announcement = await storage.createAnnouncement(announcementData);
      
      // Broadcast notification for new announcement
      broadcastNotification({
        type: 'new_announcement',
        announcementId: announcement.id,
        title: announcement.title,
        content: announcement.content,
        announcementType: announcement.type,
        timestamp: new Date()
      });
      
      res.status(201).json(announcement);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid announcement data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating announcement" });
    }
  });

  // Public announcements endpoint
  app.get("/api/announcements", async (req, res) => {
    try {
      const { type } = req.query;
      let announcements;
      
      if (type) {
        announcements = await storage.getAnnouncements(type as string);
      } else {
        announcements = await storage.getAnnouncements();
      }
      
      res.json(announcements);
    } catch (error) {
      res.status(500).json({ message: "Error fetching announcements" });
    }
  });
  
  app.get("/api/announcements/active", async (req, res) => {
    try {
      const announcements = await storage.getActiveAnnouncements();
      res.json(announcements);
    } catch (error) {
      res.status(500).json({ message: "Error fetching active announcements" });
    }
  });
  
  app.get("/api/announcements/types", async (req, res) => {
    try {
      // Return all announcement types
      const types = Object.values(AnnouncementTypes);
      res.json(types);
    } catch (error) {
      res.status(500).json({ message: "Error fetching announcement types" });
    }
  });
  
  app.get("/api/announcements/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const announcement = await storage.getAnnouncementById(id);
      if (!announcement) {
        return res.status(404).json({ message: "Announcement not found" });
      }
      res.json(announcement);
    } catch (error) {
      res.status(500).json({ message: "Error fetching announcement" });
    }
  });
  
  app.post("/api/announcements", async (req, res) => {
    try {
      // In a real app, we would check for admin permissions here
      const announcementData = insertAnnouncementSchema.parse(req.body);
      const announcement = await storage.createAnnouncement(announcementData);
      
      // If announcement is active, broadcast a notification
      if (announcement.isActive) {
        broadcastNotification({
          type: 'new_announcement',
          announcementId: announcement.id,
          title: announcement.title,
          content: announcement.content,
          announcementType: announcement.type,
          timestamp: new Date()
        });
      }
      
      res.status(201).json(announcement);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid announcement data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating announcement" });
    }
  });
  
  app.patch("/api/announcements/:id", async (req, res) => {
    try {
      // In a real app, we would check for admin permissions here
      const id = parseInt(req.params.id);
      const announcement = await storage.getAnnouncementById(id);
      if (!announcement) {
        return res.status(404).json({ message: "Announcement not found" });
      }
      
      const announcementUpdate = insertAnnouncementSchema.partial().parse(req.body);
      const updatedAnnouncement = await storage.updateAnnouncement(id, announcementUpdate);
      
      // If announcement was made active, broadcast a notification
      if (!announcement.isActive && updatedAnnouncement?.isActive) {
        broadcastNotification({
          type: 'new_announcement',
          announcementId: updatedAnnouncement.id,
          title: updatedAnnouncement.title,
          content: updatedAnnouncement.content,
          announcementType: updatedAnnouncement.type,
          timestamp: new Date()
        });
      }
      
      res.json(updatedAnnouncement);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid announcement data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating announcement" });
    }
  });
  
  app.delete("/api/announcements/:id", async (req, res) => {
    try {
      // In a real app, we would check for admin permissions here
      const id = parseInt(req.params.id);
      const announcement = await storage.getAnnouncementById(id);
      if (!announcement) {
        return res.status(404).json({ message: "Announcement not found" });
      }
      
      await storage.deleteAnnouncement(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting announcement" });
    }
  });
  
  // Challenge endpoints
  app.get("/api/challenges", async (req, res) => {
    try {
      const { category } = req.query;
      let challenges;
      
      if (category) {
        challenges = await storage.getChallenges(category as string);
      } else {
        challenges = await storage.getChallenges();
      }
      
      res.json(challenges);
    } catch (error) {
      res.status(500).json({ message: "Error fetching challenges" });
    }
  });
  
  app.get("/api/challenges/categories", async (req, res) => {
    try {
      // Return all challenge categories
      const categories = Object.values(ChallengeCategories);
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Error fetching challenge categories" });
    }
  });
  
  app.get("/api/challenges/active", async (req, res) => {
    try {
      const challenges = await storage.getActiveChallenges();
      res.json(challenges);
    } catch (error) {
      res.status(500).json({ message: "Error fetching active challenges" });
    }
  });
  
  app.get("/api/challenges/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const challenge = await storage.getChallengeById(id);
      if (!challenge) {
        return res.status(404).json({ message: "Challenge not found" });
      }
      res.json(challenge);
    } catch (error) {
      res.status(500).json({ message: "Error fetching challenge" });
    }
  });
  
  app.post("/api/challenges", async (req, res) => {
    try {
      // In a real app, we would check for admin permissions here
      const challengeData = insertChallengeSchema.parse(req.body);
      const challenge = await storage.createChallenge(challengeData);
      
      // Broadcast notification for new challenge
      broadcastNotification({
        type: 'new_challenge',
        challengeId: challenge.id,
        title: challenge.title,
        description: challenge.description,
        category: challenge.category,
        timestamp: new Date()
      });
      
      res.status(201).json(challenge);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid challenge data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating challenge" });
    }
  });
  
  app.patch("/api/challenges/:id", async (req, res) => {
    try {
      // In a real app, we would check for admin permissions here
      const id = parseInt(req.params.id);
      const challenge = await storage.getChallengeById(id);
      if (!challenge) {
        return res.status(404).json({ message: "Challenge not found" });
      }
      
      const challengeUpdate = insertChallengeSchema.partial().parse(req.body);
      const updatedChallenge = await storage.updateChallenge(id, challengeUpdate);
      res.json(updatedChallenge);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid challenge data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating challenge" });
    }
  });
  
  app.delete("/api/challenges/:id", async (req, res) => {
    try {
      // In a real app, we would check for admin permissions here
      const id = parseInt(req.params.id);
      const challenge = await storage.getChallengeById(id);
      if (!challenge) {
        return res.status(404).json({ message: "Challenge not found" });
      }
      
      await storage.deleteChallenge(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting challenge" });
    }
  });
  
  // User Challenge endpoints
  app.get("/api/user/:userId/challenges", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const challenges = await storage.getUserChallenges(userId);
      res.json(challenges);
    } catch (error) {
      res.status(500).json({ message: "Error fetching user challenges" });
    }
  });
  
  app.post("/api/user/:userId/challenges/:challengeId/join", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const challengeId = parseInt(req.params.challengeId);
      
      try {
        const userChallenge = await storage.joinChallenge(userId, challengeId);
        
        // Broadcast notification
        broadcastNotification({
          type: 'challenge_joined',
          userId,
          challengeId,
          timestamp: new Date()
        });
        
        res.status(201).json(userChallenge);
      } catch (e) {
        return res.status(400).json({ message: (e as Error).message });
      }
    } catch (error) {
      res.status(500).json({ message: "Error joining challenge" });
    }
  });
  
  app.patch("/api/user/:userId/challenges/:userChallengeId/progress", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const userChallengeId = parseInt(req.params.userChallengeId);
      
      const { progress } = z.object({ progress: z.number() }).parse(req.body);
      
      // Verify user challenge belongs to user
      const userChallenge = await storage.getUserChallengeById(userChallengeId);
      if (!userChallenge) {
        return res.status(404).json({ message: "User challenge not found" });
      }
      
      if (userChallenge.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to update this challenge" });
      }
      
      const updatedUserChallenge = await storage.updateUserChallengeProgress(userChallengeId, progress);
      
      // Check if challenge was completed
      if (updatedUserChallenge?.isCompleted && !userChallenge.isCompleted) {
        // Broadcast notification for challenge completion
        broadcastNotification({
          type: 'challenge_completed',
          userId,
          challengeId: userChallenge.challengeId,
          timestamp: new Date()
        });
      }
      
      res.json(updatedUserChallenge);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid progress data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating challenge progress" });
    }
  });
  
  app.post("/api/user/:userId/challenges/:userChallengeId/complete", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const userChallengeId = parseInt(req.params.userChallengeId);
      
      // Verify user challenge belongs to user
      const userChallenge = await storage.getUserChallengeById(userChallengeId);
      if (!userChallenge) {
        return res.status(404).json({ message: "User challenge not found" });
      }
      
      if (userChallenge.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to complete this challenge" });
      }
      
      const updatedUserChallenge = await storage.completeUserChallenge(userChallengeId);
      
      // Broadcast notification for challenge completion
      broadcastNotification({
        type: 'challenge_completed',
        userId,
        challengeId: userChallenge.challengeId,
        timestamp: new Date()
      });
      
      res.json(updatedUserChallenge);
    } catch (error) {
      res.status(500).json({ message: "Error completing challenge" });
    }
  });
  
  return httpServer;
}
